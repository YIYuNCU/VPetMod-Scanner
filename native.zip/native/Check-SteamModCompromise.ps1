#requires -Version 5.1
<#
Read-only, targeted Windows triage for the analyzed Steam/VPet mod samples.
Never loads sample DLLs, reads Steam credentials, or contacts remote hosts.
Only creates a new local report directory. See the accompanying Chinese guide.
#>
[CmdletBinding()]
param(
    [string[]]$SteamPath = @(),
    [string[]]$AdditionalPath = @(),
    [string[]]$ProfilePath = @(),
    [string]$OutputDirectory,
    [switch]$FileSystemOnly,
    [ValidateRange(1,1024)][int]$MaxTextMB = 64,
    [ValidateRange(100,1000000)][int]$MaxFiles = 100000
)

$ErrorActionPreference = 'Stop'
$script:KnownHashes = @{
    'fdad4cb139ad9d0e90c3c792502d3b471ee5d2dd86c61fc113df1bd63171c181' = 'native loader: asset_4g.dll'
    '1d7b4e03ad1cadb430981a43d015e455cf36e69350984236205a8d80a32d52e9' = 'SteamUI payload: gamev47.dll'
    'ec83b7e95ce6311feeb4c1a991a9dd68df2ad359c3af0808df5e4551367fb4be' = 'credential payload: msgame2.dll'
    '00fddce89e481c1997336b0a33105914cd88f3691f9252f218cb61e0659abdb8' = 'native loader: helper_5e.dll'
    '992230fe215fb684ea5d8079cb8d303f55c92ede4314094d3bd2d80870f8217e' = 'SteamUI payload: assetplu8.dll'
    'ae2719b116f1227157342f52a48f1119091b82f9a0fabc8dd0c9c76fa299f0d8' = 'credential payload: plugin_8b.dll'
    'c624e30e22edaf24cc9b73a246b4c2d7f4c8346c5fe4a597f8b17923988822b6' = 'decoded SteamUI analysis sample'
    '2e044a252da8b0b06cb3921fe4569f27ab91e7b87495dcabead4798c29e22740' = 'decoded credential analysis sample'
    'abc60cde023e6e521033fd0b35a723a85e49a07c55cfe4ed30afec27574dea2d' = 'decoded reference SteamUI sample'
    '9c22136b37d1c28eef63f5c5ff29abdf52d24ce3505c3cfa7f1f2b813538ecb5' = 'decoded reference credential sample'
}
$script:KnownNames = @('asset_4g.dll','gamev47.dll','msgame2.dll','helper_5e.dll','assetplu8.dll','plugin_8b.dll')
$script:CandidateSizes = @(139308,282220,236652,282112,236544)
$script:ContextPattern = '(?i)bvdpp\.top|ServiceAppMscopiAuto|ServiceApp360GuardLogon|_svc_launch\.bat'

function Initialize-State {
    $script:Findings = [System.Collections.Generic.List[object]]::new()
    $script:Gaps = [System.Collections.Generic.List[object]]::new()
    $script:Scopes = [System.Collections.Generic.List[object]]::new()
    $script:SeenFiles = @{}
    $script:SeenDirs = @{}
    $script:Stats = @{ FilesVisited=0; FilesHashed=0; ClientTextFiles=0; LogsChecked=0; TasksChecked=0; StartupValuesChecked=0 }
}
function Add-Finding($Category, $Confidence, $Path, $Indicators, $Meaning) {
    $script:Findings.Add([pscustomobject]@{ Category=$Category; Confidence=$Confidence; Path=$Path; Indicators=@($Indicators); Meaning=$Meaning })
}
function Add-Gap($Area, $Path, $Reason) {
    $script:Gaps.Add([pscustomobject]@{ Area=$Area; Path=$Path; Reason=$Reason })
}
function Get-ClientIndicators([string]$Text) {
    $hits = [System.Collections.Generic.List[string]]::new()
    foreach ($marker in @('/*px:b*/','/*px:e*/','window.__pxPoll','window.__pxH','window.__pxS','window.__pxCM','px_msgpoll.js','bvdpp.top','steamhelper')) {
        if ($Text.IndexOf($marker,[StringComparison]::OrdinalIgnoreCase) -ge 0) { $hits.Add($marker) }
    }
    $strong = (($hits.Contains('/*px:b*/') -and $hits.Contains('/*px:e*/')) -or
        ($hits.Contains('window.__pxPoll') -and ($hits.Contains('window.__pxH') -or $hits.Contains('window.__pxS'))) -or
        ($hits.Contains('bvdpp.top') -and ($hits.Contains('steamhelper') -or $hits.Contains('window.__pxH'))))
    [pscustomobject]@{ Hits=@($hits.ToArray()); Strong=$strong }
}
function Read-BoundedText([System.IO.FileInfo]$File, [string]$Area) {
    if ($File.Length -gt ($MaxTextMB * 1MB)) {
        Add-Gap $Area $File.FullName "File exceeds MaxTextMB=$MaxTextMB; not read."
        return $null
    }
    try { return [IO.File]::ReadAllText($File.FullName) }
    catch { Add-Gap $Area $File.FullName $_.Exception.Message; return $null }
}
function Inspect-File([System.IO.FileInfo]$File, [string]$Mode) {
    $key = $Mode + '|' + $File.FullName
    if ($script:SeenFiles.ContainsKey($key)) { return }
    $script:SeenFiles[$key] = $true
    $script:Stats.FilesVisited++
    if ($Mode -eq 'Client') {
        if ($File.Extension -notin @('.js','.html','.htm','.css','.json')) { return }
        $text = Read-BoundedText $File 'ClientText'
        if ($null -eq $text) { return }
        $script:Stats.ClientTextFiles++
        $match = Get-ClientIndicators $text
        if ($match.Hits.Count) {
            if ($match.Strong) {
                Add-Finding 'ClientInjectionMarkers' 'High' $File.FullName $match.Hits 'Known injection marker combination in a supplied/discovered Steam client resource tree; verify this is the live client.'
            } else {
                Add-Finding 'ClientSingleIndicator' 'Review' $File.FullName $match.Hits 'Single marker requires review; not sufficient to prove infection.'
            }
        }
    } elseif ($Mode -eq 'Binary') {
        if (($File.Extension -in @('.dll','.exe','.sample','.dec')) -and
            (($File.Length -in $script:CandidateSizes) -or ($File.Name -in $script:KnownNames))) {
            try {
                $hash = (Get-FileHash -LiteralPath $File.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
                $script:Stats.FilesHashed++
                if ($script:KnownHashes.ContainsKey($hash)) {
                    Add-Finding 'KnownMaliciousFile' 'High' $File.FullName @($hash,$script:KnownHashes[$hash]) 'Exact analyzed sample present on disk. A research copy or workshop download does not prove execution.'
                } elseif ($File.Name -in $script:KnownNames) {
                    Add-Finding 'NameOnlyMatch' 'Low' $File.FullName @($File.Name,$hash) 'Filename matches, hash differs; inspect manually. Name alone is not a malware verdict.'
                }
            } catch { Add-Gap 'Hash' $File.FullName $_.Exception.Message }
        }
        if ($File.Name -eq '_svc_launch.bat') {
            Add-Finding 'StartupFilename' 'Low' $File.FullName @($File.Name) 'Unconfirmed sample string indicator; filename alone does not prove persistence.'
        }
    }
}
function Walk-Tree([string]$Root, [string]$Mode) {
    try {
        $item = Get-Item -LiteralPath $Root -Force
        if (-not $item.PSIsContainer) { throw 'Expected a directory.' }
        $queue = [System.Collections.Generic.Queue[string]]::new()
        $queue.Enqueue($item.FullName)
        $script:Scopes.Add([pscustomobject]@{ Mode=$Mode; Path=$item.FullName })
        $count=0
        while ($queue.Count) {
            $dir=$queue.Dequeue()
            $key=$Mode+'|'+$dir
            if ($script:SeenDirs.ContainsKey($key)) { continue }
            $script:SeenDirs[$key]=$true
            try {
                $di=Get-Item -LiteralPath $dir -Force
                if ($di.Attributes -band [IO.FileAttributes]::ReparsePoint) {
                    Add-Gap $Mode $dir 'Reparse point skipped (junction/symlink/cloud placeholder).'; continue
                }
                $children=@(Get-ChildItem -LiteralPath $dir -Force)
            } catch { Add-Gap $Mode $dir $_.Exception.Message; continue }
            foreach ($child in $children) {
                if ($child.Attributes -band [IO.FileAttributes]::ReparsePoint) {
                    Add-Gap $Mode $child.FullName 'Reparse point skipped.'; continue
                }
                if ($child.PSIsContainer) {
                    if ($child.Name -eq '_local_patch_backup') {
                        Add-Finding 'PatchBackupDirectory' 'Review' $child.FullName @('_local_patch_backup') 'Patch backup directory exists; not proof of execution by itself.'
                        # Do not classify backed-up resources as active client files.
                        if ($Mode -eq 'Client') { continue }
                    }
                    $queue.Enqueue($child.FullName)
                } else {
                    $count++
                    if ($count -gt $MaxFiles) { Add-Gap $Mode $Root "MaxFiles=$MaxFiles reached; remaining files skipped."; return }
                    Inspect-File $child $Mode
                }
            }
        }
    } catch { Add-Gap $Mode $Root $_.Exception.Message }
}
function Check-Profile([string]$Profile) {
    $path=Join-Path $Profile 'AppData\LocalLow\guigugame\guigubahuang\px_mod.log'
    try {
        if (-not (Test-Path -LiteralPath $path -ErrorAction Stop)) { return }
        $file=Get-Item -LiteralPath $path
        if ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) { Add-Gap 'Log' $path 'Reparse point skipped.'; return }
        $text=Read-BoundedText $file 'Log'
        $script:Stats.LogsChecked++
        $hits=@()
        if ($null -ne $text) {
            foreach ($marker in @('sidecar mem sid=','sidecar jwt upload rc=','sidecar loc upload rc=','[SteamUI sp]')) {
                if ($text.Contains($marker)) { $hits+=$marker }
            }
        }
        Add-Finding 'SampleLog' $(if ($hits.Count) {'Review'} else {'Low'}) $path $hits 'Sample-associated log exists; matching messages support an execution trace. Values and log contents deliberately omitted; logs alone do not prove successful exfiltration.'
    } catch { Add-Gap 'Log' $path $_.Exception.Message }
}
function Check-HostStartup {
    foreach ($reg in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Run','HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce',
        'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run','HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run')) {
        try {
            if (-not (Test-Path -LiteralPath $reg)) { continue }
            $values=Get-ItemProperty -LiteralPath $reg
            foreach ($p in $values.PSObject.Properties) {
                if ($p.Name -like 'PS*') { continue }
                $script:Stats.StartupValuesChecked++
                $hits=@([regex]::Matches(($p.Name+' '+[string]$p.Value),$script:ContextPattern) | ForEach-Object {$_.Value} | Select-Object -Unique)
                if ($hits.Count) { Add-Finding 'StartupRegistryIndicator' 'Review' ($reg+'\'+$p.Name) $hits 'Related startup indicator; persistence in this sample was not established by static analysis. Command text omitted.' }
            }
        } catch { Add-Gap 'StartupRegistry' $reg $_.Exception.Message }
    }
    try {
        if (-not (Get-Command Get-ScheduledTask -ErrorAction SilentlyContinue)) { throw 'Get-ScheduledTask is unavailable.' }
        foreach ($task in @(Get-ScheduledTask -ErrorAction Stop)) {
            $script:Stats.TasksChecked++
            $text=$task.TaskName+' '+$task.TaskPath
            foreach ($action in $task.Actions) { $text+=' '+$action.Execute+' '+$action.Arguments }
            $hits=@([regex]::Matches($text,$script:ContextPattern) | ForEach-Object {$_.Value} | Select-Object -Unique)
            if ($hits.Count) { Add-Finding 'ScheduledTaskIndicator' 'Review' ($task.TaskPath+$task.TaskName) $hits 'Related task name/action indicator; task contents require review. This does not establish who created it.' }
        }
    } catch { Add-Gap 'ScheduledTasks' '' $_.Exception.Message }
}
function Get-Verdict {
    if (@($script:Findings | Where-Object {$_.Category -eq 'ClientInjectionMarkers'}).Count) { return 'CLIENT_MODIFICATION_INDICATORS' }
    if (@($script:Findings | Where-Object {$_.Category -eq 'KnownMaliciousFile'}).Count) { return 'KNOWN_MALICIOUS_FILES_PRESENT_EXECUTION_UNKNOWN' }
    if ($script:Findings.Count) { return 'SUSPICIOUS_TRACES_REVIEW_REQUIRED' }
    if ($script:Gaps.Count) { return 'INCOMPLETE_NO_KNOWN_INDICATORS' }
    return 'NO_KNOWN_INDICATORS_IN_SCANNED_SCOPE'
}
function Invoke-Check {
    Initialize-State
    $started=[DateTime]::UtcNow
    $steamRoots=[System.Collections.Generic.List[string]]::new()
    foreach ($p in $SteamPath) { $steamRoots.Add($p) }
    if (-not $FileSystemOnly) {
        foreach ($reg in @('HKCU:\Software\Valve\Steam','HKLM:\Software\WOW6432Node\Valve\Steam','HKLM:\Software\Valve\Steam')) {
            try {
                if (Test-Path -LiteralPath $reg) {
                    $v=Get-ItemProperty -LiteralPath $reg
                    foreach ($name in @('SteamPath','InstallPath')) {
                        $prop=$v.PSObject.Properties[$name]
                        if ($prop -and $prop.Value) { $steamRoots.Add([string]$prop.Value) }
                    }
                }
            } catch { Add-Gap 'SteamDiscovery' $reg $_.Exception.Message }
        }
        foreach ($base in @(${env:ProgramFiles(x86)},$env:ProgramFiles)) {
            if ($base) { $p=Join-Path $base 'Steam'; if (Test-Path -LiteralPath $p) { $steamRoots.Add($p) } }
        }
    }
    $libraries=[System.Collections.Generic.List[string]]::new()
    foreach ($root in @($steamRoots | Select-Object -Unique)) {
        Write-Host "Checking Steam root: $root"
        if (-not (Test-Path -LiteralPath $root -PathType Container)) { Add-Gap 'SteamRoot' $root 'Directory missing or inaccessible.'; continue }
        $libraries.Add($root)
        $foundClient=$false
        foreach ($relative in @('steamui','clientui')) {
            $p=Join-Path $root $relative
            if (Test-Path -LiteralPath $p) { $foundClient=$true; Walk-Tree $p 'Client' }
        }
        if (-not $foundClient) { Add-Gap 'SteamClient' $root 'No steamui/clientui directory found.' }
        $config=Join-Path $root 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $config) {
            $text=Read-BoundedText (Get-Item -LiteralPath $config) 'LibraryDiscovery'
            if ($null -ne $text) {
                foreach ($m in [regex]::Matches($text,'"path"\s+"([^"\r\n]+)"')) { $libraries.Add($m.Groups[1].Value.Replace('\\','\')) }
            }
        }
    }
    if (-not $steamRoots.Count) { Add-Gap 'SteamDiscovery' '' 'Steam was not found; supply -SteamPath with the actual installation directory.' }
    foreach ($library in @($libraries | Select-Object -Unique)) {
        $workshop=Join-Path $library 'steamapps\workshop\content\1920960'
        if (Test-Path -LiteralPath $workshop) { Walk-Tree $workshop 'Binary' }
        $manifest=Join-Path $library 'steamapps\appmanifest_1920960.acf'
        if (Test-Path -LiteralPath $manifest) {
            $text=Read-BoundedText (Get-Item -LiteralPath $manifest) 'VPetDiscovery'
            if ($text -match '"installdir"\s+"([^"\r\n]+)"') {
                $folder=$Matches[1]
                if ($folder -match '[/\\:]|^\.{1,2}$') { Add-Gap 'VPetDiscovery' $manifest 'Unexpected installdir; provide -AdditionalPath.' }
                else { Walk-Tree (Join-Path $library ('steamapps\common\'+$folder)) 'Binary' }
            } else { Add-Gap 'VPetDiscovery' $manifest 'Could not parse installdir.' }
        }
    }
    foreach ($p in $AdditionalPath) { Walk-Tree $p 'Binary' }
    $profiles=@($ProfilePath)
    if (-not $FileSystemOnly -and -not $profiles.Count) { $profiles=@($env:USERPROFILE) }
    foreach ($p in $profiles) { if ($p) { Check-Profile $p } }
    if (-not $FileSystemOnly) { Check-HostStartup }
    $verdict=Get-Verdict
    $report=[ordered]@{
        SchemaVersion=1; StartedUtc=$started.ToString('o'); FinishedUtc=[DateTime]::UtcNow.ToString('o')
        Verdict=$verdict; FileSystemOnly=[bool]$FileSystemOnly
        Scope=@($script:Scopes.ToArray()); ProfilesChecked=$profiles; Statistics=$script:Stats
        Findings=@($script:Findings.ToArray()); CoverageGaps=@($script:Gaps.ToArray())
        Limits=@('Targeted indicators only, not a full antivirus scan.',
            'Downloaded or research samples do not prove execution.',
            'No finding does not exclude previous execution, removed traces, renamed/modified variants, or stolen sessions.',
            'No process-memory, credential, browser-history, network, other-user-hive or antivirus-event inspection.',
            'No remote requests, DLL loading, task execution, remediation or deletion.',
            'Only listed folders and profiles are checked. Access errors and size/count limits are reported.',
            'Single names, task indicators and backup folders require corroboration.')
    }
    if (-not $OutputDirectory) { $OutputDirectory=Join-Path (Get-Location).Path ('SteamModCheck-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,8)) }
    $out=[IO.Path]::GetFullPath($OutputDirectory)
    if (Test-Path -LiteralPath $out) { throw "Report directory already exists; use a new path: $out" }
    $null=New-Item -ItemType Directory -Path $out
    $encoding=[Text.UTF8Encoding]::new($true)
    [IO.File]::WriteAllText((Join-Path $out 'report.json'),($report | ConvertTo-Json -Depth 8),$encoding)
    $lines=[System.Collections.Generic.List[string]]::new()
    $lines.Add("Verdict: $verdict")
    $lines.Add("Findings: $($script:Findings.Count); coverage gaps: $($script:Gaps.Count)")
    $lines.Add('Disk presence is not proof of execution. No indicators is not a clean bill of health.')
    foreach ($f in $script:Findings) {
        $lines.Add(''); $lines.Add("[$($f.Confidence)] $($f.Category): $($f.Path)")
        $lines.Add('Indicators: '+($f.Indicators -join ', ')); $lines.Add($f.Meaning)
    }
    foreach ($g in $script:Gaps) { $lines.Add("GAP [$($g.Area)] $($g.Path): $($g.Reason)") }
    $lines.Add(''); $lines.Add('If client injection or credible execution traces are found: stop the mod, preserve this report, revoke Steam sessions from a trusted device and repair the client from an official source.')
    [IO.File]::WriteAllLines((Join-Path $out 'summary.txt'),$lines,$encoding)
    Write-Host "Verdict: $verdict"
    Write-Host "Findings: $($script:Findings.Count); coverage gaps: $($script:Gaps.Count)"
    Write-Host "Reports: $out"
}

if ($MyInvocation.InvocationName -ne '.') { Invoke-Check }
