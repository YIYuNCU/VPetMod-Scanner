"""Extract cited disassembly windows from existing annotated dumpbin text output.

Strictly read-only with respect to the samples:
  * reads only the *.annotated.asm.txt text files produced by evidence.py
  * never opens, maps, loads or executes any DLL
  * no binary parsing, no emulation, no network access
"""
from pathlib import Path
import re

OUT = Path(__file__).resolve().parent
ART = OUT / "artifacts"          # 分析产物按目标分子目录存放
# 目标文件 → 其反汇编/字符串产物所在目录
SRC = {
    "asset_4g.dll": ART / "loader",
    "gamev47.dll.decoded.sample": ART / "gamev47",
    "msgame2.dll.decoded.sample": ART / "msgame2",
}
BASE = 0x180000000

# (file, base RVA, window length in bytes, human label)
WINDOWS = [
    ("asset_4g.dll", 0x1000, 0x260, "asset_4g ordinal_1 (读尾部配置 -> 调度两个载荷)"),
    ("asset_4g.dll", 0x1320, 0x180, "asset_4g process_payload (解密 -> 映射 -> 调用序号1)"),
    ("asset_4g.dll", 0x1cf0, 0x2f0, "asset_4g decode_payload (参数搬运/异或/流生成调用)"),
    ("asset_4g.dll", 0x1510, 0x2d0, "asset_4g 密钥流生成器 (80字节 seed -> SHA256 -> 计数器哈希)"),
    ("asset_4g.dll", 0x17e0, 0x300, "asset_4g manually_map_PE (分配/复制/重定位/导入解析/入口调用)"),

    ("msgame2.dll.decoded.sample", 0x1000, 0x120, "msgame2 ordinal_1 -> main"),
    ("msgame2.dll.decoded.sample", 0x4850, 0x180, "msgame2 main (选项/权限/扫描/上传)"),
    ("msgame2.dll.decoded.sample", 0x49e6, 0xa0, "msgame2 启用 SeDebugPrivilege"),
    ("msgame2.dll.decoded.sample", 0x4a90, 0x110, "msgame2 scan_steam_memory (入口/调用)"),
    ("msgame2.dll.decoded.sample", 0x5440, 0x130, "msgame2 内存扫描主体"),
    ("msgame2.dll.decoded.sample", 0x54a7, 0xb0, "msgame2 JWT 头部特征"),
    ("msgame2.dll.decoded.sample", 0x5550, 0x110, "msgame2 匹配 steam.exe / OpenProcess"),
    ("msgame2.dll.decoded.sample", 0x56da, 0x60, "msgame2 ReadProcessMemory 调用点 1"),
    ("msgame2.dll.decoded.sample", 0x586c, 0x60, "msgame2 ReadProcessMemory 调用点 2"),
    ("msgame2.dll.decoded.sample", 0x6190, 0x250, "msgame2 upload_all (内存结果 /vdf 分支)"),
    ("msgame2.dll.decoded.sample", 0x1530, 0x1a0, "msgame2 parse_local_steam_cache (vdf 路径与 ConnectCache)"),
    ("msgame2.dll.decoded.sample", 0x3620, 0x60, "msgame2 DPAPI 解密调用点"),
    ("msgame2.dll.decoded.sample", 0x64b0, 0x180, "msgame2 encode_and_post (JSON -> AES-CBC -> Base64 -> d=)"),
    ("msgame2.dll.decoded.sample", 0x669f, 0x80, "msgame2 载荷格式串与发送调用"),
    ("msgame2.dll.decoded.sample", 0x1d50, 0x1a0, "msgame2 https_post (WinHttp 调用序列)"),

    ("gamev47.dll.decoded.sample", 0x1000, 0x120, "gamev47 ordinal_1 -> main"),
    ("gamev47.dll.decoded.sample", 0x1b60, 0x120, "gamev47 main -> patch 调度"),
    ("gamev47.dll.decoded.sample", 0x1d8a, 0x60, "gamev47 调用 0x102d0"),
    ("gamev47.dll.decoded.sample", 0xa988, 0x50, "gamev47 注入 px_msgpoll 脚本"),
    ("gamev47.dll.decoded.sample", 0xaddb, 0x50, "gamev47 注入 /*px:b*/ 主脚本"),
    ("gamev47.dll.decoded.sample", 0x7b50, 0x14, "gamev47 插入 /sp.js 标签"),
]


HEXDIGITS = set("0123456789ABCDEFabcdef")


def is_hex(text):
    return bool(text) and all(c in HEXDIGITS for c in text)


def load_index(path):
    """Map VA -> reconstructed single-line instruction from dumpbin text.

    dumpbin emits two leading spaces, the 16-digit VA, a colon, then the
    machine-code bytes and the mnemonic; long instructions wrap onto
    continuation lines holding only bytes, which are dropped here.
    """
    index = {}
    order = []
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if ":" not in raw:
            continue
        head, _, body = raw.partition(":")
        head = head.strip()
        if len(head) != 16 or not is_hex(head):
            continue
        body = body.strip()
        if not body:
            continue
        # Machine-code bytes and mnemonic are separated by a wide gap.
        gap = re.search(r"\s{2,}", body)
        if gap is None:
            continue
        text = body[gap.end():].strip()
        comment = ""
        if ";" in text:
            text, _, tail = text.partition(";")
            comment = tail.strip()
            text = text.rstrip()
        addr = int(head, 16)
        index[addr] = text + (" ; " + comment if comment else "")
        order.append(addr)
    return index, order


def window(index, order, base_rva, size):
    lo, hi = BASE + base_rva, BASE + base_rva + size
    chosen = [a for a in order if lo <= a < hi]
    return [(a, index[a]) for a in chosen]


def render(records, label, source):
    out = ["```asm", f"; {label}", f"; source: {source}  (RVA = VA - 0x180000000)"]
    for addr, text in records:
        out.append(f"{addr - BASE:#08x}  {text}")
    out.append("```")
    return "\n".join(out)


def main():
    cache = {}
    narrative, appendix = [], []
    for name, rva, size, label in WINDOWS:
        key = name + ".annotated.asm.txt"
        if key not in cache:
            cache[key] = load_index(SRC[name] / key)
        index, order = cache[key]
        records = window(index, order, rva, size)
        if not records:
            print(f"!! empty window: {name} {rva:#x} {label}")
        narrative.append(render(records, label, key))
        appendix.append(render(records, label, key))
    (OUT / "flow_evidence.asm.md").write_text(
        "# 流程证据：按引用地址提取的反汇编窗口\n\n"
        "由 `extract_flow.py` 从既有 `*.annotated.asm.txt` 文本中提取，"
        "仅做文本切片与续行合并；未打开、未映射、未执行任何 DLL。\n\n"
        + "\n\n".join(appendix) + "\n",
        encoding="utf-8")
    (OUT / "flow_evidence_index.txt").write_text(
        "\n".join(f"{n}\t{r:#x}\t{s:#x}\t{l}" for n, r, s, l in WINDOWS) + "\n",
        encoding="utf-8")
    print(f"windows={len(WINDOWS)}")


if __name__ == "__main__":
    main()
