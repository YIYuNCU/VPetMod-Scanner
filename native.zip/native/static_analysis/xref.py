"""Locate cross-references to selected data addresses inside the annotated dumps.

Text-only: reads the *.annotated.asm.txt produced by evidence.py.
"""
from pathlib import Path
import sys

OUT = Path(__file__).resolve().parent
ART = OUT / "artifacts"
SRC = {
    "asset_4g.dll": ART / "loader",
    "gamev47.dll.decoded.sample": ART / "gamev47",
    "msgame2.dll.decoded.sample": ART / "msgame2",
}
sys.stdout.reconfigure(encoding="utf-8")
BASE = 0x180000000

TARGETS = {
    "msgame2.dll.decoded.sample": [
        (0x29F10, "JWT 头部特征（十六进制字符串）"),
        (0x2B5E8, "JSON 载荷格式串"),
        (0x2B608, "AES-CBC 字样"),
        (0x2B890, '"ConnectCache" 键名'),
        (0x378BA, "CryptUnprotectData 字符串"),
        (0x29550, "/check.php?id="),
        (0x38120, "AES 密钥/表引用数据地址"),
    ],
    "gamev47.dll.decoded.sample": [
        (0x325B8, "steamhelper URL 模板"),
        (0x32610, "api/messages URL 模板"),
        (0x32668, "gate.php URL 模板"),
        (0x324F0, "/check.php?id="),
        (0x34AD0, "px_msgpoll 脚本"),
        (0x34B50, "/*px:b*/ 主脚本"),
        (0x35FB0, "/sp.js script 标签"),
    ],
}


def main():
    for name, targets in TARGETS.items():
        path = SRC[name] / (name + ".annotated.asm.txt")
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        print("#" * 20, name)
        for addr, label in targets:
            needle = f"{BASE + addr:016X}h"
            hits = [l.strip() for l in lines if needle in l]
            print(f"\n-- {label}  VA={BASE+addr:#x} RVA={addr:#x}  hits={len(hits)}")
            for h in hits[:6]:
                body = h.split(":", 1)[1].strip() if ":" in h else h
                print("   ", body[:200])
            if len(hits) > 6:
                print(f"    ... {len(hits)-6} more")


if __name__ == "__main__":
    main()
