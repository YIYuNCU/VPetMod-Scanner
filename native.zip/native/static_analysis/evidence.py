"""Annotate static disassembly and extract inert text evidence."""
from pathlib import Path
import hashlib
import json
import re
from analyze import ROOT, OUT, PE, out_dir

GAME=OUT/'gamev47'; MSG=OUT/'msgame2'; LOADER=OUT/'loader'; FAMILY=OUT/'family'
for _d in (GAME,MSG,LOADER,FAMILY): _d.mkdir(parents=True,exist_ok=True)
DEST={'asset_4g.dll':LOADER,'gamev47.dll.decoded.sample':GAME,'msgame2.dll.decoded.sample':MSG}
from decode_payloads import decode

other=ROOT.parent.parent/'depot_1920960_4637760495230589419'/'native'
pairs=[('asset_4g.dll','helper_5e.dll'),('gamev47.dll','assetplu8.dll'),('msgame2.dll','plugin_8b.dll')]
comparison=[]
for a,b in pairs:
    left=(ROOT/a).read_bytes(); right=(other/b).read_bytes()
    lp,rp=PE(left),PE(right)
    record=dict(current=a,reference=b,reference_sha256=hashlib.sha256(right).hexdigest(),sections={})
    for ls,rs in zip(lp.sections,rp.sections):
        record['sections'][ls['name']]=left[ls['raw']:ls['raw']+ls['size']]==right[rs['raw']:rs['raw']+rs['size']]
    if a!='asset_4g.dll':
        left=decode(left)[0]; right=decode(right)[0]
    else:
        left=left[:-44]; right=right[:-44]
    differences=[i for i,(x,y) in enumerate(zip(left,right)) if x!=y]
    record['decoded_or_stripped_equal']=left==right
    record['decoded_or_stripped_differing_bytes']=len(differences)
    record['difference_offsets_hex']=[hex(x) for x in differences[:200]]
    record['reference_decoded_or_stripped_sha256']=hashlib.sha256(right).hexdigest()
    if a!='asset_4g.dll':
        # Independently resolve both timestamp fields using the PE directories.
        time_offsets=[lp.pe+8,lp.off(lp.dirs[6][0])+4]
        masked_left=bytearray(left); masked_right=bytearray(right)
        for off in time_offsets:
            masked_left[off:off+4]=b'\0'*4; masked_right[off:off+4]=b'\0'*4
        record['timestamp_offsets']=[hex(o) for o in time_offsets]
        record['equal_after_masking_two_timestamps']=masked_left==masked_right
        assert record['equal_after_masking_two_timestamps']
    comparison.append(record)
(FAMILY/'reference_comparison.json').write_text(json.dumps(comparison,indent=2),encoding='utf-8')

for name in ['asset_4g.dll','gamev47.dll.decoded.sample','msgame2.dll.decoded.sample']:
    dest=DEST[name]
    path=(ROOT if name=='asset_4g.dll' else dest)/name
    pe=PE(path.read_bytes())
    symbols={pe.base+x['iat_rva']:x['dll']+'!'+x['name'] for x in pe.imports()}
    for line in (dest/(name+'.strings.txt')).read_text(encoding='utf-8').splitlines():
        m=re.match(r'offset=0x[0-9a-f]+ RVA=0x([0-9a-f]+) (?:ascii|utf-16le) (.*)',line)
        if m: symbols[pe.base+int(m[1],16)]=repr(m[2][:220])
    lines=(dest/(name+'.asm.txt')).read_text(encoding='utf-8',errors='replace').splitlines()
    annotated=[]
    for line in lines:
        refs=re.findall(r'\[([0-9A-F]{16})h\]',line)
        for r in refs:
            addr=int(r,16)
            if addr in symbols: continue
            try:
                off=pe.off(addr-pe.base)
                # Read referenced short or interior strings missed by bulk scanning.
                raw=pe.data[off:off+500]
                if len(raw)>3 and raw[1]==0 and 32<=raw[0]<127:
                    units=[]
                    for k in range(0,len(raw)-1,2):
                        ch=int.from_bytes(raw[k:k+2],'little')
                        if not ch: break
                        if not 32<=ch<127: units=[]; break
                        units.append(chr(ch))
                    if len(units)>=3: symbols[addr]=repr(''.join(units)[:220])
                elif b'\0' in raw:
                    value=raw.split(b'\0',1)[0]
                    if len(value)>=3 and all(32<=x<127 for x in value): symbols[addr]=repr(value.decode()[:220])
            except ValueError: pass
        labels=[symbols[int(r,16)] for r in refs if int(r,16) in symbols]
        annotated.append(line+(' ; '+' | '.join(labels) if labels else ''))
    (dest/(name+'.annotated.asm.txt')).write_text('\n'.join(annotated),encoding='utf-8')

js=[]
for line in (GAME/'gamev47.dll.decoded.sample.strings.txt').read_text(encoding='utf-8').splitlines():
    if any(s in line for s in ('function','/*px:', 'SupportMessages','HelpAppPage','HelpFrontPage','<script','__px','navigator.clipboard')):
        js.append(line)
(FAMILY/'recovered_javascript_fragments.txt').write_text(
    'Extracted static string fragments, not a complete runnable script.\n'
    'Sample placeholders and split strings are retained. Do not paste into a browser.\n\n'+'\n\n'.join(js),encoding='utf-8')
print(json.dumps(comparison,indent=2))
