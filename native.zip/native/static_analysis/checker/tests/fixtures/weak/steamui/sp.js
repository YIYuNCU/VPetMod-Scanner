// Isolated indicator for testing review-only classification: steamhelper
