// Benign test resource. A file called sp.js is not a malware indicator.
window.testFixture = true;
