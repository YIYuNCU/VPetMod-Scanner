#requires -Version 5.1
$ErrorActionPreference='Stop'
$native=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$checker=Join-Path $native 'Check-SteamModCompromise.ps1'
. $checker
function Assert-True($Condition,$Message) { if (-not $Condition) { throw "FAIL: $Message" } }
Initialize-State
$m=Get-ClientIndicators '/*px:b*/window.__pxPoll=1;window.__pxH="x";/*px:e*/'
Assert-True $m.Strong 'Injection combination must be strong'
Assert-True (-not (Get-ClientIndicators 'normal sp.js').Strong) 'Filename alone must not trigger'
Assert-True (-not (Get-ClientIndicators 'steamhelper').Strong) 'Single generic marker must be review only'
$run=Join-Path $PSScriptRoot ('results-'+[Guid]::NewGuid().ToString('N'))
foreach ($case in @('clean','injected','weak','backup')) {
    $out=Join-Path $run $case
    & $checker -FileSystemOnly -SteamPath (Join-Path $PSScriptRoot "fixtures\$case") -OutputDirectory $out
    $r=Get-Content -LiteralPath (Join-Path $out 'report.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    $expected=@{clean='NO_KNOWN_INDICATORS_IN_SCANNED_SCOPE';injected='CLIENT_MODIFICATION_INDICATORS';weak='SUSPICIOUS_TRACES_REVIEW_REQUIRED';backup='SUSPICIOUS_TRACES_REVIEW_REQUIRED'}
    Assert-True ($r.Verdict -eq $expected[$case]) "$case verdict: $($r.Verdict)"
    Assert-True ($r.Statistics.TasksChecked -eq 0) 'Offline check must not inspect host tasks'
    Assert-True ($r.Statistics.StartupValuesChecked -eq 0) 'Offline check must not inspect host registry'
}
$out=Join-Path $run 'log'
& $checker -FileSystemOnly -SteamPath (Join-Path $PSScriptRoot 'fixtures\clean') -ProfilePath (Join-Path $PSScriptRoot 'fixtures\profile') -OutputDirectory $out
$raw=Get-Content -LiteralPath (Join-Path $out 'report.json') -Raw -Encoding UTF8
Assert-True (-not $raw.Contains('DO_NOT_EXPORT_TEST_SECRET')) 'Never export log values'
$r=$raw | ConvertFrom-Json
Assert-True (@($r.Findings | Where-Object Category -eq 'SampleLog').Count -eq 1) 'Log should be detected'
$out=Join-Path $run 'missing'
& $checker -FileSystemOnly -SteamPath (Join-Path $PSScriptRoot 'fixtures\missing') -OutputDirectory $out
$r=Get-Content -LiteralPath (Join-Path $out 'report.json') -Raw -Encoding UTF8 | ConvertFrom-Json
Assert-True ($r.Verdict -eq 'INCOMPLETE_NO_KNOWN_INDICATORS') 'Missing root must not be clean'
# Hash the original samples as data, without loading them or visiting host paths.
Initialize-State
foreach ($name in @('asset_4g.dll','gamev47.dll','msgame2.dll')) { Inspect-File (Get-Item -LiteralPath (Join-Path $native $name)) 'Binary' }
Assert-True ($script:Stats.FilesHashed -eq 3) 'Hash all three originals'
Assert-True ($script:Findings.Count -eq 3) 'All three original hashes should match'
Assert-True ((Get-Verdict) -eq 'KNOWN_MALICIOUS_FILES_PRESENT_EXECUTION_UNKNOWN') 'Disk presence must not mean execution'
Write-Host "PASS: marker, benign, weak, backup, log privacy, missing path, exact hash and offline checks. Results: $run"
