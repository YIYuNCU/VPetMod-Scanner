"""Pure byte/hash reconstruction of asset_4g RVA 0x1510 and 0x1cf0.

No emulation, sample loading, native sample calls, or network access.
"""
from pathlib import Path
import hashlib
import json
import struct
from analyze import ROOT, OUT, PE, inspect, out_dir

def decode(data):
    pe=PE(data)
    assert len(data)>=108 and struct.unpack_from('<I',data,len(data)-4)[0]==104
    t=data[-108:-4]
    # Caller rbp = rsp+0x100; trailer bytes begin at rsp+0x60.
    # K at rbp-0x30 is (t[8:24]^t[40:56]) || (t[24:40]^t[56:72]).
    key=bytes(a^b for a,b in zip(t[8:40],t[40:72]))
    seed=key+t[40:72]+t[72:88]
    assert len(seed)==80
    digest=hashlib.sha256(seed).digest()
    regions=[struct.unpack_from('<II',t,88),struct.unpack_from('<II',t,96)]
    total=sum(length for rva,length in regions)
    assert total<64*1024*1024
    stream=b''.join(hashlib.sha256(digest+struct.pack('<I',i)).digest() for i in range((total+31)//32))
    result=bytearray(data[:-108]); cursor=0; records=[]
    for rva,length in regions:
        off=pe.off(rva)
        assert off+length<=len(result)
        result[off:off+length]=bytes(a^b for a,b in zip(result[off:off+length],stream[cursor:cursor+length]))
        records.append(dict(rva=rva,offset=off,length=length,stream_offset=cursor))
        cursor+=length
    restored=PE(result)
    imports=restored.imports(); exports=restored.exports()
    assert len(imports)>50 and exports==[dict(ordinal=1,rva=4096)]
    assert any(i['dll'].lower()=='kernel32.dll' for i in imports)
    roundtrip=bytearray(result)
    for rec in records:
        off,n,k=rec['offset'],rec['length'],rec['stream_offset']
        roundtrip[off:off+n]=bytes(a^b for a,b in zip(roundtrip[off:off+n],stream[k:k+n]))
    assert bytes(roundtrip)+data[-108:]==data
    return bytes(result),dict(seed_hex=seed.hex(),seed_sha256=digest.hex(),regions=records,imports=len(imports),exports=exports)

if __name__=='__main__':
    records={}
    for name in ('gamev47.dll','msgame2.dll'):
        original=(ROOT/name).read_bytes()
        result,meta=decode(original)
        dest=out_dir(ROOT/name)
        dest.mkdir(parents=True,exist_ok=True)
        target=dest/(name+'.decoded.sample')
        target.write_bytes(result)
        meta['original_sha256']=hashlib.sha256(original).hexdigest()
        meta['decoded_sha256']=hashlib.sha256(result).hexdigest()
        # Recheck the original sample was not changed by analysis.
        assert (ROOT/name).read_bytes()==original
        records[name]=meta
        inspect(target)
    (OUT/'family').mkdir(parents=True,exist_ok=True)
    (OUT/'family'/'decode_manifest.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
