"""Offline PE inspection. Reads sample bytes; never loads sample code."""
from pathlib import Path
import collections
import hashlib
import json
import math
import re
import struct
import subprocess

ROOT = Path(__file__).resolve().parent.parent
HERE = Path(__file__).resolve().parent
OUT = HERE / 'artifacts'          # 分析产物根目录（按目标分子目录）
DUMPBIN = Path(r'C:\Program Files\Microsoft Visual Studio\18\Community\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\dumpbin.exe')

def out_dir(path):
    """产物归属：原始载荷 → 各自目录；还原副本 → 同目录（与来源文件配对）。"""
    stem = path.stem                      # 去掉扩展名，如 'gamev47'
    if stem.endswith('.decoded'):         # gamev47.dll.decoded.sample
        stem = stem[:-len('.decoded')]
    return OUT / stem

class PE:
    def __init__(self, data):
        self.data = data
        assert data[:2] == b'MZ'
        self.pe = self.u32(0x3c)
        assert data[self.pe:self.pe+4] == b'PE\0\0'
        self.opt = self.pe + 24
        assert self.u16(self.opt) == 0x20b
        self.base = self.u64(self.opt+24)
        self.entry = self.u32(self.opt+16)
        self.dirs = [struct.unpack_from('<II', data, self.opt+112+i*8) for i in range(16)]
        self.sections = []
        start = self.opt + self.u16(self.pe+20)
        for i in range(self.u16(self.pe+6)):
            o = start+40*i
            vs, va, size, raw = struct.unpack_from('<IIII', data, o+8)
            self.sections.append(dict(name=data[o:o+8].rstrip(b'\0').decode(),rva=va,virtual_size=vs,raw=raw,size=size))
    def u16(self,o): return struct.unpack_from('<H',self.data,o)[0]
    def u32(self,o): return struct.unpack_from('<I',self.data,o)[0]
    def u64(self,o): return struct.unpack_from('<Q',self.data,o)[0]
    def off(self,rva):
        for s in self.sections:
            if s['rva'] <= rva < s['rva']+s['size']:
                return s['raw']+rva-s['rva']
        if 0 <= rva < self.u32(self.opt+60): return rva
        raise ValueError(f'Unmapped RVA {rva:#x}')
    def rva(self,off):
        for s in self.sections:
            if s['raw'] <= off < s['raw']+s['size']:
                return s['rva']+off-s['raw']
        return off
    def z(self,off):
        end=self.data.index(0,off)
        return self.data[off:end].decode('ascii')
    def imports(self):
        result=[]
        if not self.dirs[1][0]: return result
        o=self.off(self.dirs[1][0])
        for i in range(100):
            oft,ts,fw,name,ft=struct.unpack_from('<IIIII',self.data,o+20*i)
            if not any((oft,ts,fw,name,ft)): break
            dll=self.z(self.off(name))
            for j in range(5000):
                v=self.u64(self.off(oft or ft)+8*j)
                if not v: break
                fn=f'#{v & 0xffff}' if v>>63 else self.z(self.off(v)+2)
                result.append(dict(dll=dll,name=fn,iat_rva=ft+8*j))
        return result
    def exports(self):
        if not self.dirs[0][0]: return []
        o=self.off(self.dirs[0][0]); base,n=self.u32(o+16),self.u32(o+20)
        ft=self.off(self.u32(o+28))
        assert n < 10000
        return [dict(ordinal=base+i,rva=self.u32(ft+4*i)) for i in range(n)]

def entropy(b):
    return -sum((n/len(b))*math.log2(n/len(b)) for n in collections.Counter(b).values()) if b else 0

def inspect(path):
    data=path.read_bytes(); pe=PE(data)
    meta=dict(file=str(path),size=len(data),sha256=hashlib.sha256(data).hexdigest(),entry_rva=pe.entry,image_base=pe.base,sections=[],directories=pe.dirs)
    for s in pe.sections:
        b=data[s['raw']:s['raw']+s['size']]
        meta['sections'].append(dict(**s,entropy=entropy(b),sha256=hashlib.sha256(b).hexdigest()))
    end=max(s['raw']+s['size'] for s in pe.sections)
    meta['overlay']=dict(offset=end,size=len(data)-end,hex=data[end:].hex())
    for key in ('imports','exports'):
        try: meta[key]=getattr(pe,key)()
        except (ValueError,struct.error,UnicodeError,AssertionError) as e: meta[key+'_error']=str(e)
    lines=[]
    strings=[]
    for encoding,pattern in [('ascii',rb'[\x20-\x7e]{5,}'),('utf-16le',rb'(?:[\x20-\x7e]\x00){5,}')]:
        for m in re.finditer(pattern,data):
            value=m.group().decode(encoding)
            strings.append(dict(offset=m.start(),rva=pe.rva(m.start()),encoding=encoding,value=value))
    strings.sort(key=lambda s:s['offset'])
    for s in strings:
        lines.append(f"offset=0x{s['offset']:08x} RVA=0x{s['rva']:08x} {s['encoding']} {s['value']}")
    dest=out_dir(path)
    dest.mkdir(parents=True,exist_ok=True)
    (dest/(path.name+'.strings.txt')).write_text('\n'.join(lines),encoding='utf-8')
    (dest/(path.name+'.json')).write_text(json.dumps(meta,indent=2),encoding='utf-8')
    if DUMPBIN.exists():
        for suffix,args in [('headers.txt',['/headers','/imports','/exports']),('asm.txt',['/disasm:bytes'])]:
            result=subprocess.run([str(DUMPBIN),*args,str(path)],capture_output=True,check=False)
            (dest/(path.name+'.'+suffix)).write_text(result.stdout.decode('mbcs',errors='replace'),encoding='utf-8')
            if result.returncode: print('dumpbin warning',path.name,result.returncode)
    print(path.name,meta['sha256'],'imports',len(meta.get('imports',[])),'exports',meta.get('exports',meta.get('exports_error')))
    return meta

if __name__=='__main__':
    for p in ROOT.glob('*.dll'): inspect(p)
